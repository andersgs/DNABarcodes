===========
DNA Barcodes
===========

DNA Barcodes is an extension to ``BioPython`` that helps one manage their DNA barcoding projects. It takes as input raw trace files, and outputs annotated barcodes ready for further analysis. It contains a wrapper for ``Phred``, ``Phrap``, and ``PolyPhred``, for high quality, validated, base-calling and barcode assembly. Individual barcodes are kept as ``Barcode`` objects within a ``ZOPE`` database. A ``DNABarcodes`` class object holds the collection of ``Barcode`` objects, and implements methods to query the database. You will find it particularly useful for small to medium sized DNA barcoding projects (up to few thousand barcodes) which do not rely on the Barcoding of Life standard COI barcode.
