from distutils.core import setup

setup(
    name='DnaBarcodes',
    version='0.1',
    author='Anders Goncalves da Silva',
    author_email='andersgs@gmail.com',
    packages=['dnabarcodes'],
    scripts=['bin/run_dnabarcodes.py','bin/create_barcode_proj.py','bin/parse_flanks.py','bin/test_regex.py'],
    url='http://pypi.python.org/pypi/DnaBarcodes/',
    license='LICENSE.txt',
    description='Manage your DNA barcoding project.',
    long_description=open('README.txt').read(),
    install_requires=[
        "ZODB >= 3.10.3",
        "biopython >= 1.6.3",
        "numpy >= 1.8.1",
    ],
)
