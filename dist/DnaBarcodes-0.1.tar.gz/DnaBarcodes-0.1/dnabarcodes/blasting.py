import sys
import numpy
import os
import csv
import re

from Bio import SeqIO
from Bio.Blast import NCBIWWW
from Bio.Blast import NCBIXML
from Bio.Blast.Applications import NcbiblastnCommandline
from Bio.Blast.Applications import NcbiblastxCommandline

###############################################################################
###### WWW BLAST ##############################################################
###############################################################################

#run a blast query, save the results to blas_res.xml, and return a handle for parsing
def blastquery_WWW(barcode_obj,blast_prog = "blastn", blast_db = "nr"):
    results_handle = NCBIWWW.qblast(blast_prog,blast_db,barcode_obj.barcode.format("fasta"))
    res_file = os.path.join(barcode_obj.assembly_path,'edit_dir',barcode_obj.id+'_blast_res.xml')
    save_file = open(res_file,"w")
    save_file.write(results_handle.read())
    save_file.close()
    results_handle.close()
    return open(res_file)


#parse blast results and return a tuple with the the results needed for the contig report
def parse_blastWWW_res(blast_handle):
    blast_record = NCBIXML.read(blast_handle)
    blastTaxon = parse_blastTaxon(blast_record)
    blastAccession = blast_record.descriptions[0].accession
    blastEvalue = blast_record.alignments[0].hsps[0].expect
    blastBits = blast_record.descriptions[0].bits
    blastHitLen = blast_record.alignments[0].length
    blastIdentities = blast_record.alignments[0].hsps[0].identities
    blastPercentMatchHit = blastIdentities*1.0/blastHitLen
    blastPercentMatchQuery = blastIdentities*1.0/blast_record.query_letters
    return (blastTaxon,blastAccession,blastEvalue,blastBits,blastHitLen,blastIdentities,blastPercentMatchHit,blastPercentMatchQuery)


#parse TaxonID from the blast results
def parse_blastTaxon(blastrec):
    title = blastrec.descriptions[0].title
    desc = title.split("|")[-1]
    genus = desc.split(" ")[1]
    return genus

def wwwBlast(barcode_obj,blast_program,blast_db):
    blast_handle = blastquery_WWW(barcode_obj,blast_program,blast_db)
    (taxon, acc,evalue,bits,hitlen,idents, perMatHit, perMatQuery) = parse_blastWWW_res(blast_handle)
    blast_www_top_hit = {}
    blast_www_top_hit['taxon'] = taxon
    blast_www_top_hit['accession'] = acc
    blast_www_top_hit['evalue'] = evalue
    blast_www_top_hit['bit_score'] = bits
    blast_www_top_hit['hit_length'] = hitlen
    blast_www_top_hit['number_identity'] = idents
    blast_www_top_hit['percent_identity'] = float(idents)/hitlen
    blast_www_top_hit['percent_match_hit'] = perMatHit
    blast_www_top_hit['percent_match_query'] = perMatQuery
    return blast_www_top_hit

###############################################################################
###### Local BLAST ############################################################
###############################################################################

def blastquery_Local(query,subject,outfile):
#    cmd = NcbiblastnCommandline(query="{}".format(query), subject="{}".format(subject),out="{}".format(outfile), outfmt="\'10 qseqid sseqid pident nident evalue bitscore length\'")
    cmd = NcbiblastnCommandline(query="{}".format(query), subject="{}".format(subject),out="{}".format(outfile), outfmt="5", max_target_seqs="1")
    cmd()

def blastxquery_Local(query,subject,outfile):
    cmd = NcbiblastxCommandline(query="{}".format(query), subject="{}".format(subject),out="{}".format(outfile), outfmt="\'10 qseqid sseqid length sstart send qstart qend qframe evalue bitscore\'",max_target_seqs=1)
    cmd()


def localBlast(barcode_obj,local_db,blastx=None):
    tmp_file = os.path.join(barcode_obj.assembly_path,'tmp.fasta')
    SeqIO.write(barcode_obj.barcode,tmp_file,"fasta")
    if blastx==None:
        res_file = os.path.join(barcode_obj.assembly_path,'local_blast_res.csv')
#         all_hits = blastquery_Local(tmp_file,local_db,res_file)
#         top_hit = topHit_localBlast(parse_blastLocal_res_file(res_file))
        all_hits = blastquery_Local(tmp_file,local_db,res_file)
        top_hit = parse_blastLocal_res_file(res_file)
    elif blastx:
        res_file = os.path.join(barcode_obj.assembly_path,'local_blastx_res.csv')
        all_hits = blastxquery_Local(tmp_file,local_db,res_file)
        top_hit = topHit_localBlast(parse_blastxLocal_res_file(res_file))
    os.remove(tmp_file)
    return top_hit

def topHit_localBlast(records):
    rec_sorted = multikeysort(records,['-bit_score','evalue'])
    return rec_sorted[0]    


def multikeysort(items, columns):
    from operator import itemgetter
    comparers = [ ((itemgetter(col[1:].strip()), -1) if col.startswith('-') else (itemgetter(col.strip()), 1)) for col in columns]
    def comparer(left, right):
        for fn, mult in comparers:
            result = cmp(fn(left), fn(right))
            if result:
                return mult * result
            else:
                return 0
    return sorted(items, cmp=comparer)

def parse_blastLocal_res(key, value, type):
    if type == str:
        return (key,value)
    if type == int:
        return (key,int(value))
    if type == float:
        return (key,float(value))

# def parse_blastLocal_res_file(blastFile):
#     try:
#         infile_hand = open(blastFile,'r')
#     except:
#         print "Could not open file {}.".format(blastFile)
#         raise
#     
#     read_hand = csv.reader(infile_hand,delimiter=",")
#     tokens = ["query_id","accession","percent_identity","number_identity","evalue","bit_score","alignment_length"]
#     unit = [str,str,float,int,float,int,int]
#     #species = ["Haemoproteus", "Leucocytozoon", "Plasmodium"]
#     
#     if os.path.getsize(blastFile) == 0:
#         res = []
#         res.append(dict({'query_id':'?','bit_score':0,'evalue':0}))
#         return res
# 
# 
#     summ = numpy.zeros([6,8])
#     
#     res = []
#     for line in read_hand:
#         res.append(dict((parse_blastLocal_res(tokens[n],value,unit[n]) for n,value in enumerate(line))))
#     infile_hand.close()
#     return res

def parse_blastxLocal_res_file(blastFile):
    try:
        infile_hand = open(blastFile,'r')
    except:
        print "Could not open file {}.".format(blastFile)
        raise
    
    if os.path.getsize(blastFile) == 0:
        res = []
        res.append(dict({'query_frame':'?','bit_score':0,'evalue':0}))
        return res

    read_hand = csv.reader(infile_hand,delimiter=",")
    tokens = ["query_id","accession","length","subject_start","subject_end","query_start","query_end","query_frame","evalue","bit_score"]
    unit = [str,str,int,int,int,int,int,int,float,float]
    #species = ["Haemoproteus", "Leucocytozoon", "Plasmodium"]
    
    summ = numpy.zeros([6,8])
    
    res = []
    for line in read_hand:
        res.append(dict((parse_blastLocal_res(tokens[n],value,unit[n]) for n,value in enumerate(line))))
    infile_hand.close()
    return res


def parse_blastLocal_res_file(blastfile):
	res_handle = open(blastfile)
	records = NCBIXML.parse(res_handle)
	res = dict()
	hits = []
	for rec in records:
		if rec.alignments != []:
			hits.append(rec)
	if len(hits) == 1:
		rec = hits[0]
		res['query_id'] = rec.query.split()[0]
		title = rec.alignments[0].title.split('|')
		res['accession'] = title[0].split()[1]
		try:
			res['taxon'] = re.search('taxon=\w*',title[1]).group().split('=')[1]
		except:
			res['taxon'] = ''
		try:
			res['genbank'] = re.search('genbank=\w*',title[1]).group().split('=')[1]
		except:
			res['genbank'] = ''
		align = rec.alignments[0].hsps[0]
		res['number_identity'] = align.identities
		res['alignment_length'] = align.align_length
		res['percent_identity'] = float(res['number_identity'])/res['alignment_length']
		res['evalue'] = align.expect
		res['bit_score'] = int(align.bits)
	else:
		print 'too many hits'
	res_handle.close()
	return res

# def summ_res(data):
#     return (numpy.mean(data),numpy.std(data,ddof=1))


# def contig_blastSum(blastFile):

#   res = parse_blast_res_file(blastFile)
    
#   total_matches = len(res)
    
#   count = 1
#   sp_matches = []
#   for i,token in enumerate(tokens[2:]):
#       tmp_data = [float(rec[token]) for rec in res]
#       (total_mean,total_sd) = summ_res(tmp_data)
#       tmp_sp_summ = []
#       for sp in species:
#           tmp_sp_data = numpy.array([dat for n,dat in enumerate(tmp_data) if re.search(sp,res[n]['subjectID'])])
#           tmp_sp_summ.append([summ_res(tmp_sp_data)])
#           if count is 1:
#               sp_matches.append(len(tmp_sp_data))
#       count += 1
#       tmp_res = numpy.append([tmp_sp_summ],[total_mean,total_sd])
#       summ[i,:] = tmp_res
#   matches = [[m,float(m)/total_matches] for m in sp_matches]
#   matches = numpy.append(matches,[total_matches,1.0])
#   summ[-1,:] = matches    
#   return summ

# def mash_contigReport_malaviTopHit(table,topHits,outfile):
#   try:
#       outf_hand = open(outfile,'w')
#       outf_writer = csv.writer(outf_hand,delimiter=",",quoting=csv.QUOTE_MINIMAL)
#       header = ['id','length','qual','multInf','countAmbigBases','malavi_match_blast','malAviID','percentMatch','genebankAcc','genus','numbMatches','lengthAlign','bitscore','eValue','blast_taxon','blast_accession','blast_percentIdent','blast_hitLength','blast_bitScore','blast_eValue']
#       outf_writer.writerow(header)
#   except:
#       print "Could not open file {}.".format(outfile)
#       raise
    
#   temps = table.cols.contigID[:]
#   recs = []
#   outf_writer = csv.writer(outf_hand,delimiter=",",quoting=csv.QUOTE_MINIMAL)
#   for temp in temps:
#       row = table.readWhere('contigID==\"{}\"'.format(temp))
#       hit = [rec for rec in topHits if rec['queryID']==temp][0]
#       #contig info
#       id = temp
#       length = row['length'][0]
#       qual = row['percentBasesQ20plus'][0]
#       multiInf = row['multipleInfectionStatus'][0]
#       countAmbBases = row['countBasesAmbiguous'][0]
#       #malavi blast top hit info
#       (malAviID,genebankAcc,genus)=hit['subjectID'].split("|")
#       percentMatch = hit['percentIdent']
#       numbMatches = hit['numberIdent']
#       lengthAlign = hit['lengthAlign']
#       bitscore = hit['bitScore']
#       eValue = hit['eValue']
#       #ncbi top hit info
#       bTaxon = row['blastTaxon'][0]
#       bAcc = row['blastAcc'][0]
#       bPercentIdent = row['blastIdentities'][0]
#       bLength = row['blastHitLen'][0]
#       bBitScore = row['blastBits'][0]
#       bEvalue = row['blastEvalue'][0]
#       malavi_blast_match = 'Yes' if genebankAcc == bAcc else 'No'
#       rec = dict(zip(header,[id,length,qual,multiInf,countAmbBases,malavi_blast_match,malAviID,percentMatch,genebankAcc,genus,numbMatches,lengthAlign,bitscore,eValue,bTaxon,bAcc,bPercentIdent,bLength,bBitScore,bEvalue]))
#       recs.append(rec)
    
#   recs_sort = sorted(recs,key=lambda k: (-k['qual'],-k['percentMatch']))
    
#   rows = []
    
#   for rec in recs_sort:
#       row = []
#       for token in header:
#           if token == 'qual' or token == 'eValue' or token == 'blast_eValue' or token == 'blast_bitScore' or token == 'bitscore':
#               row.append("{:.3f}".format(rec[token]))
#           elif token == 'percentMatch' or token == 'blast_percentIdent':
#               row.append("{:.2f}".format(rec[token]))
#           else:
#               row.append(rec[token])
#       rows.append(row)
#   outf_writer.writerows(rows)
#   outf_hand.close()
    
#   return recs_sort


# def mash_to_html(mash_file):
#   outfile = mash_file.split(".csv")[0]
#   outfile = outfile.split("/")[-1]
#   outfile = outfile + ".html"
    
#   try:
#       outf_hand = open(outfile,'w')
#   except:
#       print "Could not open the file {}.".format(outfile)
#       raise

#   try:
#       inf_hand = open(mash_file,'r')
#       in_reader = csv.reader(inf_hand,delimiter=",")
#   except:
#       print "Could not open the file {}.".format(outfile)
#       raise

    
#   #write header
#   #open the table
#   outf_hand.write("<table>\n\t<body>\n")
    
#   #column colouring
#   #contig columns
#   outf_hand.write("\t\t<col span=\"6\" style=\"background-color: #cccc99; color: #ffffff; border: 2px solid #000000;\"/>\n")
    
#   #malavi columns
#   outf_hand.write("\t\t<col span=\"8\" style=\"background-color: #99cc99; color: #ffffff; border: 2px solid #000000;\"/>\n")
    
#   #ncbi columns
#   outf_hand.write("\t\t<col span=\"6\" style=\"background-color: #cccc66; color: #ffffff; border: 2px solid #000000;\"/>\n")
    
#   outf_hand.write("\t\t\t<tr>\n")
    
#   outf_hand.write("\t\t\t\t<td colspan=\"6\"> Contig Information </td>\n")
#   outf_hand.write("\t\t\t\t<td colspan=\"8\"> MalAvi Top Hit Information </td>\n")
#   outf_hand.write("\t\t\t\t<td colspan=\"6\"> NCBI BLAST Top Hit Information </td>\n")
    
#   outf_hand.write("\t\t\t</tr>\n")
    
#   #write out table
#   for row in in_reader:
#       outf_hand.write("\t\t\t<tr>\n")
#       for rec in row: 
#           outf_hand.write("\t\t\t\t<td>{}</td>\n".format(rec))
#       outf_hand.write("\t\t\t</tr>\n")
    
#   #close table
#   outf_hand.write("\t</body>\n</table>\n")
#   outf_hand.close()