#!/usr/bin/env python

'''
a program that configures dnabarcode projects
'''

import sys, re, os
import ConfigParser

def create():
	config = ConfigParser.SafeConfigParser()
	
	config.add_section('metadata')
	
	config.set('metadata','project_basename','dbcodes')
	config.set('metadata','home_folder',os.getcwd())
	config.set('metadata','traces_folder',os.path.join(config.get('metadata','home_folder'),'traces/'))
	config.set('metadata','trace_ext','ab1')
	config.set('metadata','barcodes_folder',os.path.join(config.get('metadata','home_folder'),'barcodes/'))
	config.set('metadata','ref_folder',os.path.join(config.get('metadata','home_folder'),'ref_db/'))
	config.set('metadata','reports_folder',os.path.join(config.get('metadata','home_folder'),'reports/'))
	config.set('metadata','regex',"B_((K[0-9]{6})|([0-9]{3}-[0-9]{5}))_[0-9]{2}")
	config.set('metadata','copy_phd','False')
	config.set('metadata','dbcodes_db',config.get('metadata','project_basename')+'_zodb.fs')
	config.set('metadata','append','False')
	
	config.add_section('tasks')
	
	config.set('tasks','run_phredphrap','True')
	config.set('tasks','run_wwwBlast','True')
	config.set('tasks','wwwBlast_flavour','blastn')
	config.set('tasks','run_localBlast','True')
	config.set('tasks','localBlast_flavour','blastn')
	config.set('tasks','correct_readingFrame','True')
	config.set('tasks','wwwBlast_db','nr')
	config.set('tasks','localBlast_db',os.path.join(config.get('metadata','ref_folder'),'localBlast_db.fa'))
	config.set('tasks','localBlastX_db',os.path.join(config.get('metadata','ref_folder'),'localBlastX_db.fa'))
	config.set('tasks','vector_db', os.path.join(config.get('metadata','ref_folder'),'vector.seq'))
	
	config.add_section('reports')
	
	config.set('reports','out_barcodes','True')
	config.set('reports','bcode_format','fasta')
	config.set('reports','bcode_fname','barcodes')
	config.set('reports','bcode_minQ','20')
	config.set('reports','bcode_minQP','0.975')

	fh = open("dbcode.cfg",'wb')
	
	config.write(fh)
	
	fh.close()
	
	return config

def read(filename):
	config = ConfigParser.SafeConfigParser()
	fh = open(filename)
	config.readfp(fh)
	fh.close()
		
	return config
	
