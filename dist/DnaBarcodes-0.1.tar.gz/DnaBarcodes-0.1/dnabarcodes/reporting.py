
import sys,csv
import numpy as np

def quality_check(proportionQ20plus):
    if proportionQ20plus >= 0.975:
        qual = 'high'
    elif proportionQ20plus >=0.95:
        qual = 'acceptable'
    elif proportionQ20plus > 0:
        qual = 'low'
    else:
        qual = 'failed'
    return qual


def summary_tables(data,fw_reads,fw_samples):
    qual_dict = {
    'high':0,
    'acceptable':1,
    'low':2,
    'failed':3
    }
    res_reads = np.zeros((5,3))
    res_samp = np.zeros((4,4))
    
    for rec in data:
        qual1 = qual_dict[quality_check(rec[3])]
        qual2 = qual_dict[quality_check(rec[6])]
        res_reads[qual1,0]+=1
        res_reads[qual2,1]+=1
        res_samp[qual1,qual2] += 1
    
    #outputting read summary file
    col_names_reads = ['QC_Category','Primer1','Primer2','Total']
    row_names_reads = np.array(['High','Acceptable','Low','Failed','Total'])
    for i in range(0,4):
    	res_reads[i,2]=sum(res_reads[i,:])
    for j in range(0,3):
    	res_reads[4,j] = sum(res_reads[:,j])
    res_reads = np.column_stack((row_names_reads,res_reads))

    fw_reads.writerow(col_names_reads)
    fw_reads.writerows(res_reads)

     #output sample summary file
    col_names_samples = ['Scores','High','Acceptable','Low','Failed']
    row_names_samples = np.array(['High','Acceptable','Low','Failed'])

    res_samp = np.column_stack((row_names_samples,res_samp))

    fw_samples.writerow(col_names_samples)
    fw_samples.writerows(res_samp)

    #return [res_reads,res_samp]

def run_csv_report(table,runID,outfn = "junk_read"):
	#here we assume there is a forward and reverse primer
	#table is a reads table for a single run (in our case of a Sanger machine)
	#the table is in numpy format
	
	#open the file to write
	outfn = outfn+runID+".csv"
	outf_hand = open(outfn,'w')
	outf_csv = csv.writer(outf_hand,delimiter=",",quoting=csv.QUOTE_MINIMAL)
		
	#figure the templates
	temps = numpy.unique(table["templateID"])
	print "Run {} had {} templates.".format(runID, len(temps))
	
	#primers
	prims = numpy.unique(table["primer"])
	print "Run {} used {} primers.".format(runID,len(prims))
	
	#create a row for each templateID, and then write it to file
	for template in temps:
		tmp_row = [template]
		recs = table[table["templateID"]==template]
		if len(recs) == 0:
			break
		else:
			for p in prims:
				tmp_row.append(p)
				if sum(recs['primer']==p) == 0:
					tmp_row.extend([0,0])
					continue
				tmp_row.extend(recs[recs['primer']==p]['length'])
				tmp_row.extend(recs[recs['primer']==p]['percentBasesQ20plus'])
		outf_csv.writerow(tmp_row)
	outf_hand.close()

def new_table(fn,summary="",caption=""):
	fn.write("<table summary={} align=\"center\">\n<caption>{}</caption>\n\t<body>\n".format(summary,caption))

def close_table(fn):
	fn.write("\t</body>\n</table>\n")

def new_row(fn):
	fn.write("\t\t<tr>\n")

def close_row(fn):
	fn.write("\t\t</tr>\n")
	
def status_tag(fn,value):
	if value>=0.975:
		col = "Green"
	elif value>=0.95:
		col="Yellow"
	elif value>0:
		col="Red"
	else:
		col="Grey"
	
	fn.write("\t\t\t\t\t<ac:macro ac:name=\"status\">\n")
	fn.write("\t\t\t\t\t\t<ac:parameter ac:name=\"colour\">{}</ac:parameter>\n".format(col))
	fn.write("\t\t\t\t\t\t<ac:parameter ac:name=\"title\">{:0.3f}</ac:parameter>\n".format(value))
	fn.write("\t\t\t\t\t</ac:macro>\n")	

def cell(fn,data,status):
	fn.write("\t\t\t<td>\n")
	
	if status:
		status_tag(fn,data)
	else:
		fn.write("\t\t\t\t<p>")
		fn.write("{}".format(data))
		fn.write("</p>\n")
	fn.write("\t\t\t</td>\n")
	
def cell_header(fn,data):
	fn.write("\t\t\t<td class=\"highlight\" colspan=\"1\">")
	fn.write(data)
	fn.write("</td>\n")

def cell_header_sum(fn,rowsp=True):
	if rowsp:
		fn.write("\t\t\t<td class=\"highlight\" colspan=\"1\" rowspan=\"5\">")
		fn.write("Read<BR>Primer 1</BR>")
		fn.write("</td>\n")
	else:
		fn.write("\t\t\t<td class=\"highlight\" colspan=\"5\">")
		fn.write("Read<BR>Primer 2</BR>")
		fn.write("</td>\n")
	
	
def run_html_report(table,runID,outfn = "junk_read"):
	#here we assume there is a forward and reverse primer
	#table is a reads table for a single run (in our case of a Sanger machine)
	#the table is in numpy format
	
	#open the file to write
	outfn = outfn+runID+".html"
	outf_hand = open(outfn,'w')
		
	#figure the templates
	temps = numpy.unique(table["templateID"])
	print "Run {} had {} templates.".format(runID, len(temps))
	
	#primers
	prims = numpy.unique(table["primer"])
	print "Run {} used {} primers.".format(runID,len(prims))
	
	#initiate table
	outf_hand.write("<h1>Individual template statistics and QC</h1>\n")
	new_table(outf_hand, summary="\"This table contains QC values for each template and read\"",caption="QC report for each individual template, split by primer")
	new_row(outf_hand)
	
	#create header
	for field in ["Template ID", "Primer 1", "Read Primer 1<BR>Length</BR>", "Proportion Bases<BR>&#8805;Q20</BR>","Primer 2", "Read Primer 2<BR>Length</BR>", "Proportion Bases<BR>&#8805;Q20</BR>"]:
		cell_header(outf_hand,field)
	close_row(outf_hand)
	
	#create a row for each templateID, and then write it to file
	for template in temps:
		new_row(outf_hand)
		cell(outf_hand,template,status=0)
		recs = table[table["templateID"]==template]
		for p in prims:
			cell(outf_hand,p,status=0)
			if sum(recs['primer']==p) == 0:
				cell(outf_hand,0,status=0)
				cell(outf_hand,0,status=1)
			else:
				cell(outf_hand,recs[recs['primer']==p]['length'][0],status=0)
				cell(outf_hand,recs[recs['primer']==p]['percentBasesQ20plus'][0],status=1)
		close_row(outf_hand)
	close_table(outf_hand)
	outf_hand.close()
	

def array_pos(proportionBasesQ20plus):
	if proportionBasesQ20plus >= 0.975:
		return 0
	elif proportionBasesQ20plus >= 0.95:
		return 1
	elif proportionBasesQ20plus > 0:
		return 2
	else:
		return 3
		
def sum_html_report(table,runID,outfn="junk_sum"):
	#open the file to write
	outfn = outfn+runID+".html"
	outf_hand = open(outfn,'w')
		#figure the templates
	temps = numpy.unique(table["templateID"])
	print "Run {} had {} templates.".format(runID, len(temps))
	
	#primers
	prims = numpy.unique(table["primer"])
	print "Run {} used {} primers.".format(runID,len(prims))
	
	#initialise summary tables
	n_read_qc = numpy.zeros([5,3])
	n_sample_qc = numpy.zeros([4,4])
	
	#count reads and samples
	n_reads = len(table)
	n_samples = len(numpy.unique(table['templateID']))
		
	for template in temps:
		tmp = []
		recs = table[table["templateID"]==template]
		for p in prims:
			rec = recs[recs['primer']==p]['percentBasesQ20plus']
			if len(rec) == 0:
				tmp.append(array_pos(0))
				if p == prims[0]:
					n_read_qc[array_pos(0),0] += 1 
				else:
					n_read_qc[array_pos(0),1] += 1
			else:
				tmp.append(array_pos(rec[0]))
				if p == prims[0]:
					n_read_qc[array_pos(rec[0]),0] += 1 
				else:
					n_read_qc[array_pos(rec[0]),1] += 1
		n_sample_qc[tuple(tmp)] += 1
	
	for i in [0,1,2,3,4]:
		n_read_qc[i,2]=sum(n_read_qc[i,0:2])
		if i < 3:
			n_read_qc[4,i]=sum(n_read_qc[0:4,i])

	
	#initialise the read primer sum QC table
	outf_hand.write("<h1>Summary statistics</h1>\n")
	outf_hand.write("<h2>Reads</h2>\n")
	
	new_table(outf_hand,summary="\"This table shows counts of reads within each QC category, broken down by primer, and total reads in a particular category\"",caption="Counts of reads in each QC category split by primer.")
	
	new_row(outf_hand)
	cell_header(outf_hand,"QC category")
	for p in prims:
		cell_header(outf_hand, p)
	cell_header(outf_hand,"Total")
	close_row(outf_hand)
	
	#parse values to cells
	for i,n in enumerate([0.975,0.950,0.940,0.000,"Total"]):
		new_row(outf_hand)
		if type(n) == str: 
			cell_header(outf_hand,n)
		else:
			cell(outf_hand,n,status=1)
		for j in xrange(len(prims)+1):
			cell(outf_hand,n_read_qc[i,j],status=0)
		close_row(outf_hand)
	close_table(outf_hand)
	
	#initiate sample sum QC table
	outf_hand.write("<h2>Samples</h2>\n")
	new_table(outf_hand,summary="\"This table shows counts of reads in each QC quality category for each primer pair.\"",caption="Counts of reads in each QC category across samples")
	new_row(outf_hand)
	cell_header(outf_hand,"Primers")
	cell_header_sum(outf_hand,rowsp=False)
	close_row(outf_hand)
	
	#build table
	new_row(outf_hand)
	cell_header_sum(outf_hand,rowsp=True)
	cell_header(outf_hand,"Scores")
	cell(outf_hand,0.975,status=1)
	cell(outf_hand,0.950,status=1)
	cell(outf_hand,0.940,status=1)
	cell(outf_hand,0.000,status=1)
	close_row(outf_hand)
	
	for i,n in enumerate([0.975,0.950,0.940,0.000]):
		new_row(outf_hand)
		cell(outf_hand,n,status=1)
		for j in [0,1,2,3]:
			cell(outf_hand,n_sample_qc[i,j],status=0)
		close_row(outf_hand)
	close_table(outf_hand)
	outf_hand.close()
	
	return (n_read_qc,n_sample_qc)