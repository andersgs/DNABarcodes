'''
Python scratch
'''

import sys, os, re
#import filecmp

from ZODB.FileStorage import FileStorage
from ZODB.DB import DB
import transaction

#from Bio import SeqIO

#import custom modules
import parameter_parser as pp
import stage2 as st
#import processing as pr
from sample_class import Barcode
from dnabarcodes_class import DNABarcodes

#import numpy as np

# #create dictionary of raw sequencing files
# #will have to change this function in order to allow for other types of raw sequencing data
# def create_dic_raw_files(rawpath):
#     """Return a dictionary with filename as key, and path as values"""
#     print "Searching "+rawpath+" for ab1 files...\n"
#     ab1_files = {}
#     for root,dirs,files in os.walk(rawpath):
#         for f in files:
#             if(re.search("ab1",f)):
#                 ab1_files[f]=os.path.abspath(root+"/"+f)
#     print "Found {} files.".format(len(ab1_files.keys()))
#     return ab1_files

# #based on a search pattern (regex) provided by the user, and the keys obtained from the
# #  dictionary created with create_dic_raw_files, output the sample_ids to be processed
# def sample_ids(search_pat,k):
#     """Return a list of sample ids in the file given some sample_regex"""
#     print "Checking if all files match the regex...\n"
#     pat_check = [key for key in k if search_pat.match(key) == None]
#     if len(pat_check) > 0:
#         print "A total of {} files did not match the regex.".format(len(pat_check))
#         print "The files are:"
#         for i in pat_check:
#             print i
#         print "Please check your regex, or fix the files."
#         sys.exit()
#     else:
#         print "All files were matched...\n"
#         sample_id = list(set([search_pat.match(key).group() for key in k]))
#         print "A total of {} samples were foun in {} files.".format(len(sample_id),len(k))
#         return sample_id
        
# #based on the sample_ids and the dictionary from create_dic_raw_files, output a dictionary
# # where the keys are the sample_ids, and the values are the chromat files associated
# # with those samples
# def samp_file_dic(sample_ids,files_dic):
#     f_key = files_dic.keys()
#     res = [[files_dic[k] for k in f_key if re.search(pat,k) != None] for pat in sample_ids]
#     sf_dic = {}
#     for i in range(len(sample_ids)):
#         sf_dic[sample_ids[i]] = set(res[i])
#     return sf_dic


# raw_data_path = '../avimal_ts/RawData/'

# fnames = []
# for root,dirs,files in os.walk(raw_data_path):
#     for f in files:
#         if re.search("ab1",f):
#             fnames.append(os.path.join(root,f))

# junk = create_dic_raw_files(raw_data_path)
# search_pat =re.compile('^B_((K[0-9]{6})|([0-9]{3}-[0-9]{5}))_[0-9]{2}')
# junk2 = sample_ids(search_pat,junk)
# junk3 = samp_file_dic(junk2,junk)

# junk3['B_K007206_02']

fn = '/Users/andersg/Documents/Analysis/seq_analysis/avimal_ts/dnabarcodereader_parmfile_avimal_ts.txt'
database = DNABarcodes(fn)

database.sync()
#database.samples.clear()

# database.update(junk3)

# database.add(junk3,'/Users/andersg/Documents/Analysis/seq_analysis/avimal_ts/seqs/')

# samps = database.samples

database.do_phredPhrap()

database.do_wwwBlast()

database.do_localBlast()

database.output_barcodes()

database.read_quality_reports()
