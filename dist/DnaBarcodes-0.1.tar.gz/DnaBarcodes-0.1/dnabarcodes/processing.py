
from tables import *
import os

###############################################################################
###### Creating/opening reports database ######################################
###############################################################################

def open_reports_db(reports_db_filename, append):
		
		if append:
			h5_report = open_file(reports_db_filename,mode="a")
		else:
			h5_report = open_file(reports_db_filename,mode="w",title="Sequence Report")
			read_group = h5_report.create_group("/",'reads','Reads report')
			contig_group = h5_report.create_group("/",'contigs','Contigs report')
			read_table = h5_report.create_table(read_group,'reads_qc',Reads,"Read Quality Control")
			contigs_table = h5_report.create_table(contig_group,'contig_info',Contigs, "Contig information")
		
		return h5_report


###############################################################################
###### Creating/opening fasta file ############################################
###############################################################################

def open_fasta(fasta_filename, append):
		if append:
			fa_fn = open(fasta_filename,mode="a")
		else:
			fa_fn = open(fasta_filename,mode="w")
		return fa_fn


###############################################################################
###### Contig information handling class ######################################
###############################################################################


#contigs class for use with pytables in order to report output
class Contigs(IsDescription):
	contigID = StringCol(25) # a contigID referencing the sample ID
	length = Int32Col() # the length of the contig in number of bases
	percentBasesQ20plus = FloatCol() # proportion of bases with a q-value ≥ 20
	countBasesAmbiguous = Int32Col() # proportion of bases referenced as "-"
	multipleInfectionStatus = StringCol(10) # Likelihood of multiple infection: Low if countBasesAmbiguous = 0; Medium if countBasesAmbiguous = 1; High if countBasesAmbiguous > 1 
	blastTaxon = StringCol(30) # taxon for the top BLAST result against nr using blastn
	blastAcc = StringCol(20) # the NCBI Accession code for the top BLAST hit
	blastEvalue = FloatCol() # E-value for top BLAST hit
	blastBits = FloatCol() # bit-score of the top BLAST hit
	blastHitLen = Int32Col() # length of the top BLAST hit
	blastIdentities = Int32Col() # Number of base matches between contig and top BLAST hit
	percentMatchHit = FloatCol() # proportions of matches relative to Hit length
	percentMatchQuery = FloatCol() # proportions of matches relative to Query length

#build a record to upload to the contig reports database
def contig_row_constructor(contigrec,table,sampleID):
	table.row['contigID'] = sampleID
	table.row['length'] = parse_readLength(contigrec)
	table.row['percentBasesQ20plus'] = parse_percentQ20plus(contigrec)
	countBasesAmb = parse_countBasesAmbiguous(contigrec)
	table.row['countBasesAmbiguous'] = countBasesAmb
	table.row['multipleInfectionStatus'] = parse_multipleInfectionsStatus(countBasesAmb)
	
	if 1 and os.path.isfile("blast_res.xml"):
		blast_handle = open("blast_res.xml",'r')
	else:
		blast_handle = blastquery_www(contigrec)
	
	(taxon, acc,evalue,bits,hitlen,idents, perMatHit, perMatQuery) = parse_blast_res(blast_handle)
	
	table.row['blastTaxon'] = taxon
	table.row['blastAcc'] = acc
	table.row['blastEvalue'] = evalue
	table.row['blastBits'] = bits
	table.row['blastHitLen'] = hitlen
	table.row['blastIdentities'] = idents
	table.row['percentMatchHit'] = perMatHit
	table.row['percentMatchQuery'] = perMatQuery
	table.row.append()



###############################################################################
###### Reads information handling class #######################################
###############################################################################

#reads class for use with pytables in order to report output
class Reads(IsDescription):
	templateID = StringCol(50) # PCR from which the read came from
	sampleID = StringCol(50) # sample from which the PCR was generated to make the read
	readID = StringCol(50) # Read ID information - which includes the templateID plus the tag that tells us about the primer and repeat number of that particular sample+primer combination
	readFilename = StringCol(50) # Name of the chromatogram
	runID = StringCol(25) # Run ID
	primer = StringCol(5) # NF or NR2
	length = Int32Col() # length of read after phredPhrap treatment (i.e., trimming of low quality bases and sequences outside the barcode
	percentBasesQ20plus = FloatCol() # proportion of bases with a q-value ≥ 20


#build a record to upload to the reads reports database
def read_row_constructor(seqrec,qualrec,table,dic):
	rec = table.row
	rec['templateID'] = parse_templateID(seqrec.id,'^B_((K[0-9]{6})|([0-9]{3}-[0-9]{5}))_[0-9]{2}_[0-9]{2}')
	rec['sampleID'] = parse_templateID(seqrec.id,'^B_((K[0-9]{6})|([0-9]{3}-[0-9]{5}))_[0-9]{2}')
	rec['readID'] = parse_readID(seqrec.id)
	rec['readFilename'] = seqrec.id
	rec['runID'] = parse_runID(seqrec.id,dic)
	rec['primer'] = parse_primer(parse_readID(seqrec.id))
	rec['length'] = parse_readLength(seqrec)
	rec['percentBasesQ20plus'] = parse_percentQ20plus(qualrec)
	rec.append()


###############################################################################
###### Parse information to build records in the reports database #############
###############################################################################

#returns the templateID for use in building the read report. can be re-used to create the contigID in the contig report
def parse_templateID(seqid,searchpat):
	match = re.match(searchpat,seqid)
	return match.group()

#returns the readID for use in building the read report
def parse_readID(seqid):
	return seqid.split(".")[0]
	
#return the run id to use in building the read report
def parse_runID(readFilename,dic):
	loc = dic[readFilename]
	runName = loc.split("/")[-2]
	return runName
	
#returns the primer string for use in building the read report
def parse_primer(readid):
	return readid.split("_")[-1]
	
#returns the read length for use in building the read report. Can be re-used to parse contig length in the contig report
def parse_readLength(seqrecord):
	return len(seqrecord)

#returns the percentBasesQ20plus for use in building the read report and contig report
def parse_percentQ20plus(seqrecord):
	seqLen = len(seqrecord)
	countQ20plus = sum(q >= 20 for q in seqrecord.letter_annotations['phred_quality'])
	return countQ20plus*1.0/seqLen

#because editing with Consed can result in more than one ace file in the directory, we should always pick the latest file. Versions of ace files have increasing integer suffixes after the .ace suffix. For instance, *.ace.1 is an earlier version of *.ace.2
def pick_latestAce(dir):
	ace_files = [f for f in os.listdir(dir) if re.search("ace",f)]
	ace_files.sort(reverse=True)
	return ace_files[0]
	
#returns the countAmbiguousBases for use in building the contig report
def parse_countBasesAmbiguous(contigrec):
	return sum(amb=="-" for amb in contigrec.seq)

#returns the multiple infections status, can also be a measure of how likely there is a SNP or indel in the dataset
def parse_multipleInfectionsStatus(countBasesAmb):
	if countBasesAmb is 0:
		return "Low"
	if countBasesAmb is 1:
		return "Medium"
	if countBasesAmb > 1:
		return "High"

#parse TaxonID from the blast results
def parse_blastTaxon(blastrec):
	title = blastrec.descriptions[0].title
	desc = title.split("|")[-1]
	genus = desc.split(" ")[1]
	return genus

#parse blast results and return a tuple with the the results needed for the contig report
def parse_blast_res(blast_handle):
	blast_record = NCBIXML.read(blast_handle)
	blastTaxon = parse_blastTaxon(blast_record)
	blastAccession = blast_record.descriptions[0].accession
	blastEvalue = blast_record.alignments[0].hsps[0].expect
	blastBits = blast_record.descriptions[0].bits
	blastHitLen = blast_record.alignments[0].length
	blastIdentities = blast_record.alignments[0].hsps[0].identities
	blastPercentMatchHit = blastIdentities*1.0/blastHitLen
	blastPercentMatchQuery = blastIdentities*1.0/blast_record.query_letters
	return (blastTaxon,blastAccession,blastEvalue,blastBits,blastHitLen,blastIdentities,blastPercentMatchHit,blastPercentMatchQuery)





class proc:
	def __init__(self,outfolder):
		self.__outpath = outfolder
		h5_filename = os.path.join(self.__outpath,"reports.h5")
		#h5_report.close()
		h5_report = open_file(h5_filename,mode="w",title="Sequence Report")
		read_group = h5_report.create_group("/",'reads','Reads report')
		contig_group = h5_report.create_group("/",'contigs','Contigs report')
		read_table = h5_report.create_table(read_group,'reads_qc',Reads,"Read Quality Control")
		contigs_table = h5_report.create_table(contig_group,'contig_info',Contigs, "Contig information")
		outjunk = open(tmp_path+"/"+"junk.fasta",'w')
		outstdout = open(tmp_path+"/"+"stdout.txt",'w')
		try:
			for samp in self.sample_id:
				print "************************************************************"
				print "Processing sample: {}.".format(samp)
				os.chdir(os.path.join(tmp_path,samp,"edit_dir"))
				subprocess.call(['phredPhrap'],stdout=outstdout)
				print "Done..."
				print ""
		
				print "************************************************************"
				print "Writing reads QC table results"
				print ""
		
				read_gen = SeqIO.parse(open(samp+".fasta","r"),"fasta")
				qual_gen = SeqIO.parse(open(samp+".fasta.screen.qual","r"),"qual")
		
				for r,q in zip(read_gen,qual_gen):
					read_row_constructor(r,q,read_table,self.ab1)

				ace_file = pick_latestAce(".")
				ace_gen = SeqIO.parse(open(ace_file,'r'),'ace')
				try:
					contig = ace_gen.next()
					contig.id = samp
					contig_row_constructor(contig,contigs_table,samp)
					SeqIO.write(contig,outjunk,"fasta")
				except:
					print "No contig available"
				print "************************************************************"
				print "\n\n\n"
		except:
			h5_report.close()
			print "Something went wrong"
			raise
		h5_report.close()