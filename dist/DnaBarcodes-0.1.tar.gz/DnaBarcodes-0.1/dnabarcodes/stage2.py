import os,re, shutil
from dnabarcodes import parameter_parser as pp

ow_chroms = ow_phdfiles = 0

#print out a horizontal line to divided output to screen 
def div():
		print ""	
		print "-"*80
		print ""

#create/copy all chromats to the appropriate sample project folders, each sample project
# folder contains the sub-folders necessary to run phredPhrap. The chromats are copied
#  to the chromats_dir in each sample project folder.	
def stage(barcode_obj,append,phd_copy):		
	global ow_chroms
	folder = barcode_obj.assembly_path
	dest_chrom = os.path.join(folder,'chromat_dir')
	if phd_copy:
		dest_phd = os.path.join(folder,'phd_dir')
	if barcode_obj.timestamps['phred_phrap'] == 0:
		try:
			os.mkdir(folder)
		except:
			emptydir(folder)
		for sub_dir in ['chromat_dir','phd_dir','edit_dir','poly_dir']:
			os.mkdir(os.path.join(folder,sub_dir))
		for f in barcode_obj.chromats:
			src = f
			shutil.copy(src,dest_chrom)
		if phd_copy:
			for f in barcode_obj.phd_files:
				src = f
				fn = f.split("/")[-1]
				fn = fn[0:-6]+'.ab1.phd.1'
				shutil.copyfile(src,os.path.join(dest_phd,fn))

		runs = set()
		for c in barcode_obj.chromats:
			runs.add(c.split('/')[-2])
		barcode_obj.runs = runs

		return ow_chroms
	elif append:
		for f in barcode_obj.chromats:
			src = f
			if os.path.isfile(dest_chrom):
				if ow_chroms == 3:
					break
				elif ow_chroms!=2:
					ow_chroms = overwrite_chromat(dest,ow_chroms)
					if ow_chroms:
						shutil.copy(src,dest_chrom)
					else:
						break
				else:
					shutil.copy(src,dest_chrom)
			else:
				shutil.copy(src,dest_chrom)
		if phd_copy:
			for f in barcode_obj.phd_files:
				src = f
				fn = f.split("/")[-1]
				fn = fn[0:-6]+'ab1.phd.1'
				if os.path.isfile(dest):
					if ow_phdfiles == 3:
						break
					elif ow_phdfiles!=2:
						ow_phdfiles = overwrite_chromat(dest,ow_chroms)
						if ow_phdfiles:
							shutil.copyfile(src,os.path.join(dest_phd,fn))
						else:
							break
					else:
						shutil.copyfile(src,os.path.join(dest_phd,fn))
				else:
					shutil.copyfile(src,os.path.join(dest_phd,fn))

		runs = set()
		for c in barcode_obj.chromats:
			runs.add(c.split('/')[-2])
		barcode_obj.runs = runs
		return ow_chroms
	else:
		barcode_obj.timestamps['phred_phrap'] = 0
		stage(barcode_obj)


#This function asks the user to authorise writing over existing chromats files. It is used
# within the function stage(), and is in place to avoid copying over different chromats that
# may have inadvertently been named the same. Thus, it can help catch potential naming 
# errors with the chromats.
def overwrite_chromat(sample,ow_chroms):
	if ow_chroms == 0:
		attempts = 0
		while attempts < 5:
			print "You are about to overwrite {}.\nAre you ok with this?".format(sample)
			ans = raw_input("Press:\n0 to skip;\n1 to overwrite this specific file;\n2 to overwrite all samples;\n3 to skip all overwrites.\n: ")
			if int(ans) in [0,1,2,3]:
				ow_chroms=int(ans)
				return ow_chroms
			else:
				attempt += 1
	elif ow_chroms == 1:
		ow_chroms = 0
		overwrite_chromat(sample,ow_chroms)
	elif ow_chroms == 3:
		return 0
	else:
		raise Exception("Don't know what to do with your options to overwrite. Exiting....")

#clean outfolder path
def emptydir(path):
	if(os.listdir(path) is ['.DS_Store']):
		return
	if(path == '/' or path == "\\"):
		return 
	else:
		for root, dirs, files in os.walk(path, topdown=False):
			for name in files:
				os.remove(os.path.join(root, name))
			for name in dirs:
				os.rmdir(os.path.join(root, name))