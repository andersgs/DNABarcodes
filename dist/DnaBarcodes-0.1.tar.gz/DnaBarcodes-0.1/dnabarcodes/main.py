#!/opt/local/bin/python2.7
# -*- coding: utf-8 -*-
"""
DNABarcodeReader is a Python based program that takes raw sequence data, transforms it into DNA barcodes, and outputs barcodes, a highest match of the barcode to NCBI database and/or a locally held database, and quality scores for the barcode.

The software was developed by Anders Gonçalves da Silva and Rohan H. Clarke. Coding of version 1.0 was done by Anders Gonçalves da Silva while at Monash University. 

DNABarcodeReader is maintained by Anders Gonçalves da Silva.

Contact Information:
Anders Gonçalves da Silva
andersgs at googlemail dot com 

#########################################################################################
DNABarcodeReader requires phred/phrap/Consed, and optionally, polyphred. These software must be obtained separately, and are NOT distributed as part of the standard DNABarcodeReader distribution. 

Information on how to obtain, install, and run phred/phrap/Consed can be found at: http://www.phrap.org/consed/consed.html#howToGet

Information on how to obtain, install, and run polyphred can be found at: http://droog.gs.washington.edu/polyphred/poly_get.html

#########################################################################################


THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Copyright (C) 2013 Anders Gonçalves da Siva and Rohan H. Clarke
"""
#import base modules
import sys, os, re

#import ZODB functions
from ZODB.FileStorage import FileStorage
from ZODB.DB import DB
import transaction

#import custom modules
import parameter_parser as pp
import stage2 as st
import processing as pr
from sample_class import Barcode
from dnabarcode_class import DNABarcodes

#print some simple instructions if needed
def instructions():
    print "#"*80
    print "#  DNABarcodeReader  ".ljust(79," ")+"#"
    print "#    version: 1.0".ljust(79," ")+"#"
    print "#    date: 11 September 2013".ljust(79," ")+"#"
    print "#".ljust(79," ")+"#"
    print "# To use DNABarcodeReader, you must specify a paramete file.".ljust(79," ")+"#"
    print "#    For example:".ljust(79," ")+"#"
    print "#        >./dnabarcodereader paramfile".ljust(79," ")+"#"
    print "#".ljust(79," ")+"#"
    print "# Copyright (C) 2013 Anders Gonçalves da Silva and Rohan H. Clarke".ljust(80," ")+"#"
    print "#"*80

#print section banners
def banner(title):
    print " "
    print "#"*80
    print "#"*80
    ban = "#"*10 + "  " + title + "  "
    print ban.ljust(80,"#")
    print "#"*80
    print "#"*80
    print " "


# create dictionary of raw sequencing files
# will have to change this function in order to allow for other types of raw sequencing data
def create_dic_raw_files(rawpath):
    """Return a dictionary with filename as key, and path as values"""
    print "Searching "+rawpath+" for ab1 files...\n"
    ab1_files = {}
    for root,dirs,files in os.walk(rawpath):
        for f in files:
            if(re.search("ab1",f)):
                ab1_files[f]=os.path.abspath(root+"/"+f)
    print "Found {} files.".format(len(ab1_files.keys()))
    return ab1_files

#based on a search pattern (regex) provided by the user, and the keys obtained from the
#  dictionary created with create_dic_raw_files, output the sample_ids to be processed
def sample_ids(search_pat,k):
    """Return a list of sample ids in the file given some sample_regex"""
    print "Checking if all files match the regex...\n"
    pat_check = [key for key in k if search_pat.match(key) == None]
    if len(pat_check) > 0:
        print "A total of {} files did not match the regex.".format(len(pat_check))
        print "The files are:"
        for i in pat_check:
            print i
        print "Please check your regex, or fix the files."
        #sys.exit()
        # need to add something here to inform the user how to proceed
        #return sample_id
    else:
        print "All files were matched...\n"
    sample_id = list(set([search_pat.match(key).group() for key in k if search_pat.match(key) != None]))
    print "A total of {} samples were foun in {} files.".format(len(sample_id),len(k))
    return sample_id
        
#based on the sample_ids and the dictionary from create_dic_raw_files, output a dictionary
# where the keys are the sample_ids, and the values are the chromat files associated
# with those samples
def samp_file_dic(sample_ids,files_dic):
    f_key = files_dic.keys()
    res = [[files_dic[k] for k in f_key if re.search(pat,k) != None] for pat in sample_ids]
    sf_dic = {}
    for i in range(len(sample_ids)):
        sf_dic[sample_ids[i]] = set(res[i])
    return sf_dic

#Running the main program
def main(paramfile):
    #parse the parameter file
    parameterfile = '/Users/andersg/Documents/Analysis/seq_analysis/phred_phrap_src/dnabarcodereader_parmfile.txt'
    #banner("Parsing parameter file")
    args = pp.parse_param(parameterfile)

    banner("Pre-run")
    # read all files in the raw
    st.div()
    print "Generating a list of chromats".ljust(80,".")
    
    raw_files = create_dic_raw_files(args['raw_data'])
    
    st.div()
    print "Parsing out the sample ids".ljust(80,".")
    #compile the search pattern
    pattern = re.compile(args['file_search'])
    
    samples = sample_ids(pattern, raw_files)
    
    st.div()
    print "Generating the sample:chromats pairs".ljust(80,".")
    
    sample_files_dic = samp_file_dic(samples, raw_files)

    st.div()

    db_file ='avimal_db.fs'

    database = DNABarcodes(args['db_file'],args['append'])
    #insert and update
    #update current objects with new chromats, in case they have any
    database.update(sample_files_dic)

    #add new samples to the database
    database.add(sample_files_dic,args['processing_folder'])

    #setting the samples to facilitate access
    samps = database.samples

    #start staging task
    if database.args['run_staging']:
        banner("Staging")
                
        st.div()
        print "Generating/updating assembly folders".ljust(80,".")
        
        ow_chroms=0
        for k in samps.keys():
            samps[k].stage()
        transaction.commit()
        
        st.div()
                    
    #start processing task  
    #start with phred_phrap
    if database.args['run_phredPhrap']:
        st.div()
        print "Running phredPhrap.pl".ljust(80,".")
        database.do_phredPhrap()
    else:
        print "Skipping phredPhrap.pl".ljust(80,".")
    #do www blast
    if database.args['run_NCBIBlast']:
        print "Running NCBI Blast".ljust(80,".")
        database.do_wwwBlast()
    else:
        print "Skipping NCBI Blast".ljust(80,".")
    #do local blast
    if database.args['run_localBlast']:
        print "Running local Blast".ljust(80,".")
        database.do_localBlast()
    else:
        print "Skipping local Blast".ljust(80,".")

    #start reporting
    
    print "Starting reporting".ljust(80,".")
    
    if database.args['output_barcodes_file']:
        print "Writing barcode sequences to file".ljust(80,".")
        database.output_barcodes()
    else:
        print "Skipping outputting barcodes to file".ljust(80,".")

    
    print "Outputting reads QC summary reports in CSV".ljust(80,".")
    
    if args['out_read_HTML']:
        print "Outputting reads QC summary reports in HTML".ljust(80,".")
    
    print "Outputting contigs QC summary reports in CSV".ljust(80,".")  

    if args['out_contig_HTML']:
        print "Outputting contigs QC summary reports in HTML".ljust(80,".")
        
    print "All done".ljust(80,".")

#The bit that brings it all together.
if __name__=="__main__":
    
    if len(sys.argv) != 2:
        instructions()
    else:
        main(sys.argv[1])