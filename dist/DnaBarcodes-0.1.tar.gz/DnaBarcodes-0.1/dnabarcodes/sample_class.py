'''
Define an object (class) to hold all information associated with barcoding a sample.
'''
#general libraries
import os
import numpy
import re
import datetime

#biopython modules
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from Bio.Alphabet import IUPAC
from Bio import SeqIO
from Bio.Blast import NCBIWWW
from Bio.Blast import NCBIXML

#creating persistent objects
import persistent

#custom modules
from dnabarcodes import stage2 as st
from dnabarcodes import processing2 as pr
from dnabarcodes import blasting as bl

class Barcode(persistent.Persistent):
    '''
    A class used by DNABarcodeReader to store information relative to each sample's barcode in a project.
    ''' 
    def __init__(self,project_path,sample_id,chromat_files,phd_files = None):

        # a string to identify the object, related to the sample used to generate the template that was sequenced
        self.id = sample_id

        #project path
        # where the project will be kept. it will be the parent directory for the assembly path
        self.project_path = os.path.abspath(project_path)

        #assembly path
        #the path to phred,phrap folder where all the dna barcoding generation data is kept, and where the chromats need to be copied too
        self.assembly_path = os.path.abspath(os.path.join(self.project_path,sample_id))

        # a set to store current chromatograms associated with this object
        self.chromats = chromat_files

        # a set to store current chromatograms associated with this object
        self.phd_files = phd_files

        # create a set of runs that have this template, used for reporting purposes
        self.runs = set()

        # a set to store the reads associated with this object.
        # the reads are stored as Bio.SeqRecord objects with quality values
        self.reads = set()

        #read summary data, to be used in reporting
        self.read_sum = 0

        # a SeqRecord holding the contig currently associated with this object
        self.barcode = 0

        # an identifier that relates the sample to a particular record in a barcoding database.
        # in our case, it will pull out the closest match in the malavi database
        # the value is stored as tuple, with the first argument a string with the reference to the database, and the second a float indicating the percent match

        self.database_id = ()

        #local blast top hit match data
        self.blast_local_top_hit = {}

        #NCBI blast top hit
        self.blast_www_top_hit = {}

        #taxonomic information 
        self.taxon = ()

        #timestamps
        self.timestamps = {
        'chromats':0,
        'phred_phrap':0,
        'contig':0,
        'blast_www':0,
        'blast_local':0,
        'blastx_local':0
        }

    def stage(self,append = False,phd_copy = False):
        '''
        '''
        st.stage(self,append,phd_copy)

    def phred_phrap(self,vectorfile):
        '''
        Run phred, phrap and, optionally, polyPhred. Then, store reads and contig in appropriate places in the object. If because we are updating the contig, we must reset the BLAST data.
        '''
        pr.phred_phrap(self,vectorfile)
        self.update_reads()
        self.update_barcode()

    def blast_www(self,blast_program,blast_db):
        '''
        This functions performs a BLAST search of the contig against the NCBI database
        '''
        self.blast_www_top_hit = bl.wwwBlast(self,blast_program,blast_db)


    def blast_local(self,local_db,blastx=None):
        if blastx==None:
            self.blast_local_top_hit = bl.localBlast(self,local_db)
        elif blastx:
            if self.barcode != 0:
                res = bl.localBlast(self,local_db,blastx)
                self.blast_local_top_hit['frame'] = res['query_frame']
            # else:
            #     continue

    def report(self):
        pass

    def update_chromat(self,new_chromats,new_phd=None):
        '''
        This function updates the object by adding new chromatograms to the object. In doing so, it resets the object so that a new barcode is forced to be generated using the new chromats.
        '''
        self.barcode = 0
        self.database_id = ()
        self.blast_local_top_hit = []
        self.blast_www_top_hit =[]
        self.taxon = ()
        self.read_sum = 0
        self.chromats.update(new_chromats)
        if new_phd != None:
            self.phd.update(new_phd)

    def update_reads(self):
        print "Writing reads QC"
        read_gen = SeqIO.parse(open(self.id+".fasta","r"),"fasta")
        qual_gen = SeqIO.parse(open(self.id+".fasta.screen.qual","r"),"qual")
        for rec in read_gen:
            qual = qual_gen.next()
            rec.letter_annotations['phred_quality'] = qual.letter_annotations['phred_quality']
            self.reads.add(rec)
        self.read_report()

    def read_report(self):
        if self.read_sum == 0:
            self.read_sum = {}
            for r in self.runs:
                self.read_sum[r] = []
                for c in self.chromats:
                    if re.search(r,c):
                        for s in self.reads:
                            if re.search(s.id,c):
                                self.read_sum[r].append([('_').join(s.id.split('_')[0:-1]),(s.id.split('_')[-1]).split('.')[0],len(s),sum(map(lambda x: 1 if x>=20 else 0,s.letter_annotations['phred_quality']))/float(len(s))])
            return self.read_sum
        else:
            return self.read_sum

    def update_barcode(self):
        folder = os.path.join(self.assembly_path,'edit_dir')
        ace_file = pr.pick_latestAce(folder)
        ace_gen = SeqIO.parse(open(ace_file,'r'),'ace')
        try:
            contig = ace_gen.next()
            contig.id = self.id
            self.barcode = contig
        except:
            print "No contig available"
        print "************************************************************"
        print "\n\n\n"

        #if contig is update, all BLAST information is reset
        self.database_id = ()

        #local blast top hit match data
        self.blast_local_top_hit = []

        #NCBI blast top hit
        self.blast_www_top_hit =[]

        #taxonomic information 
        self.taxon = ()
