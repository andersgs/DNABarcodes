# coding: utf-8
"""
stage.py is part of the phred_phrap_pop_pipeline library. It will take a directory, search ab1 files, parse the file names to group by sample, create sample specific sub-directories ready for phred_phrap, and will copy the sequences to chromat_dir ready for phredPhrap.pl module

Author: Anders Goncalves da Silva
Started on: 13 March 2013

Licence: GPL/3

History:
13 August 13:
* branched to version 1.0 on git. The idea is to reduce the amount of sample matching that happens within the code, and simply point out to the user that the files need to be fixed before continuing. This way, the user only needs to submit a regex expression to find the sample id information, and then the primer information from the file names provided. 
* want to add a facility to keep track of files that have already been processed. that way the project can grow without having to repeat a whole lot of computation.

15 August 13:
* added some functionality to keep track of runs that have already been processed. But, have not finished this yet. It still needs a way to write to file the runs that were processed in this turn.
*it will now generate the appropriate folders, and copy the chromatograms. 
*I need to add a debugging feature that will wipe the out folder if it exists, and start again.
* also need to ask the user if it is already to overwrite files

16 August 13
* the class chromat will now finish the staging process, and then run phredPhrap.pl over the whole dataset
* now, I need someway of outputting summary reports, and flagging sequences that need my attention:
	* either because they are too long or too short
	* or because they have polymorphisms identified with polyPhred
	* or low quality (missing one or more primers)
* I had to modify the following files to make them work with this project (files are in /usr/local/genomes/bin/:
	* phredPhrap.pl:
		-removed references to nice - no need here
		-made sure the reference to vector.seq pointed to /Users/andersg/Documents/seq_analysis/avimal_ts/vector.seq by setting the CROSS_MATCH_VECTOR parameter in my .profile folder
		-set the vector.seq file to contain the HaemF and HaemR2 primers – still need to get cross_match to match appropriately for some of the reads
	* determineReadTypes.perl: tweaked the search pattern so that it would match my own sequence names – need to tweak further in order to recognise the primers names and their direction
	*tagRepeats.perl: made sure the direction to repeats.fasta was pointing to /Users/andersg/Documents/seq_analysis/avimal_ts/repeats.fasta
	
20 August 2013
* added the ability to output a FASTA file with all the new contigs in the database.
* still needs some improvement on several fronts. The total contigs file should be appended if the project is growing. 
* needs to give some more information in the description of the FASTA file.
* needs BLASTing.

22 August 2013
* code is working, but still needs cleaning up.
* must add reporting services

"""
import sys,os,re,difflib,math,shutil,time,subprocess
from shlex import shlex
from Bio import SeqIO
from Bio.Blast import NCBIWWW
from Bio.Blast import NCBIXML
from tables import *

#local modules
import parameter_parser as pp


# code for debugging purposes. it purges the outfolder
def emptydir(top):
	if(os.listdir(top) is ['.DS_Store']):
		return
	if(top == '/' or top == "\\"):
		return 
	else:
		for root, dirs, files in os.walk(top, topdown=False):
			for name in files:
				os.remove(os.path.join(root, name))
			for name in dirs:
				os.rmdir(os.path.join(root, name))
		
#contigs class for use with pytables in order to report output
class Contigs(IsDescription):
	contigID = StringCol(25) # a contigID referencing the sample ID
	length = Int32Col() # the length of the contig in number of bases
	percentBasesQ20plus = FloatCol() # proportion of bases with a q-value ≥ 20
	countBasesAmbiguous = Int32Col() # proportion of bases referenced as "-"
	multipleInfectionStatus = StringCol(10) # Likelihood of multiple infection: Low if countBasesAmbiguous = 0; Medium if countBasesAmbiguous = 1; High if countBasesAmbiguous > 1 
	blastTaxon = StringCol(30) # taxon for the top BLAST result against nr using blastn
	blastAcc = StringCol(20) # the NCBI Accession code for the top BLAST hit
	blastEvalue = FloatCol() # E-value for top BLAST hit
	blastBits = FloatCol() # bit-score of the top BLAST hit
	blastHitLen = Int32Col() # length of the top BLAST hit
	blastIdentities = Int32Col() # Number of base matches between contig and top BLAST hit
	percentMatchHit = FloatCol() # proportions of matches relative to Hit length
	percentMatchQuery = FloatCol() # proportions of matches relative to Query length

#reads class for use with pytables in order to report output
class Reads(IsDescription):
	templateID = StringCol(50) # PCR from which the read came from
	sampleID = StringCol(50) # sample from which the PCR was generated to make the read
	readID = StringCol(50) # Read ID information - which includes the templateID plus the tag that tells us about the primer and repeat number of that particular sample+primer combination
	readFilename = StringCol(50) # Name of the chromatogram
	runID = StringCol(25) # Run ID
	primer = StringCol(5) # NF or NR2
	length = Int32Col() # length of read after phredPhrap treatment (i.e., trimming of low quality bases and sequences outside the barcode
	percentBasesQ20plus = FloatCol() # proportion of bases with a q-value ≥ 20

#returns the templateID for use in building the read report. can be re-used to create the contigID in the contig report
def parse_templateID(seqid,searchpat):
	match = re.match(searchpat,seqid)
	return match.group()

#returns the readID for use in building the read report
def parse_readID(seqid):
	return seqid.split(".")[0]
	
#return the run id to use in building the read report
def parse_runID(readFilename,dic):
	loc = dic[readFilename]
	runName = loc.split("/")[-2]
	return runName
	
#returns the primer string for use in building the read report
def parse_primer(readid):
	return readid.split("_")[-1]
	
#returns the read length for use in building the read report. Can be re-used to parse contig length in the contig report
def parse_readLength(seqrecord):
	return len(seqrecord)

#returns the percentBasesQ20plus for use in building the read report and contig report
def parse_percentQ20plus(seqrecord):
	seqLen = len(seqrecord)
	countQ20plus = sum(q >= 20 for q in seqrecord.letter_annotations['phred_quality'])
	return countQ20plus*1.0/seqLen

#because editing with Consed can result in more than one ace file in the directory, we should always pick the latest file. Versions of ace files have increasing integer suffixes after the .ace suffix. For instance, *.ace.1 is an earlier version of *.ace.2
def pick_latestAce(dir):
	ace_files = [f for f in os.listdir(dir) if re.search("ace",f)]
	ace_files.sort(reverse=True)
	return ace_files[0]
	
#returns the countAmbiguousBases for use in building the contig report
def parse_countBasesAmbiguous(contigrec):
	return sum(amb=="-" for amb in contigrec.seq)

#returns the multiple infections status, can also be a measure of how likely there is a SNP or indel in the dataset
def parse_multipleInfectionsStatus(countBasesAmb):
	if countBasesAmb is 0:
		return "Low"
	if countBasesAmb is 1:
		return "Medium"
	if countBasesAmb > 1:
		return "High"

#run a blast query, save the results to blas_res.xml, and return a handle for parsing
def blastquery_www(contigrec,blast_prog = "blastn", blast_db = "nr"):
	results_handle = NCBIWWW.qblast(blast_prog,blast_db,contigrec.format("fasta"))
	save_file = open("blast_res.xml","w")
	save_file.write(results_handle.read())
	save_file.close()
	results_handle.close()
	return open("blast_res.xml")

#parse TaxonID from the blast results
def parse_blastTaxon(blastrec):
	title = blastrec.descriptions[0].title
	desc = title.split("|")[-1]
	genus = desc.split(" ")[1]
	return genus

#parse blast results and return a tuple with the the results needed for the contig report
def parse_blast_res(blast_handle):
	blast_record = NCBIXML.read(blast_handle)
	blastTaxon = parse_blastTaxon(blast_record)
	blastAccession = blast_record.descriptions[0].accession
	blastEvalue = blast_record.alignments[0].hsps[0].expect
	blastBits = blast_record.descriptions[0].bits
	blastHitLen = blast_record.alignments[0].length
	blastIdentities = blast_record.alignments[0].hsps[0].identities
	blastPercentMatchHit = blastIdentities*1.0/blastHitLen
	blastPercentMatchQuery = blastIdentities*1.0/blast_record.query_letters
	return (blastTaxon,blastAccession,blastEvalue,blastBits,blastHitLen,blastIdentities,blastPercentMatchHit,blastPercentMatchQuery)


#read row constructor: output a table row entry with a read object
def read_row_constructor(seqrec,qualrec,table,dic):
	rec = table.row
	rec['templateID'] = parse_templateID(seqrec.id,'^B_((K[0-9]{6})|([0-9]{3}-[0-9]{5}))_[0-9]{2}_[0-9]{2}')
	rec['sampleID'] = parse_templateID(seqrec.id,'^B_((K[0-9]{6})|([0-9]{3}-[0-9]{5}))_[0-9]{2}')
	rec['readID'] = parse_readID(seqrec.id)
	rec['readFilename'] = seqrec.id
	rec['runID'] = parse_runID(seqrec.id,dic)
	rec['primer'] = parse_primer(parse_readID(seqrec.id))
	rec['length'] = parse_readLength(seqrec)
	rec['percentBasesQ20plus'] = parse_percentQ20plus(qualrec)
	rec.append()

def contig_row_constructor(contigrec,table,sampleID):
	table.row['contigID'] = sampleID
	table.row['length'] = parse_readLength(contigrec)
	table.row['percentBasesQ20plus'] = parse_percentQ20plus(contigrec)
	countBasesAmb = parse_countBasesAmbiguous(contigrec)
	table.row['countBasesAmbiguous'] = countBasesAmb
	table.row['multipleInfectionStatus'] = parse_multipleInfectionsStatus(countBasesAmb)
	
	if 1 and os.path.isfile("blast_res.xml"):
		blast_handle = open("blast_res.xml",'r')
	else:
		blast_handle = blastquery_www(contigrec)
	
	(taxon, acc,evalue,bits,hitlen,idents, perMatHit, perMatQuery) = parse_blast_res(blast_handle)
	
	table.row['blastTaxon'] = taxon
	table.row['blastAcc'] = acc
	table.row['blastEvalue'] = evalue
	table.row['blastBits'] = bits
	table.row['blastHitLen'] = hitlen
	table.row['blastIdentities'] = idents
	table.row['percentMatchHit'] = perMatHit
	table.row['percentMatchQuery'] = perMatQuery
	table.row.append()

def div():
		print ""	
		print "_"*80
		print ""

class chromats:
	"""Find all chromatograms in a folder. If no folder is supplied, the current working directory is assumed."""
	def __init__(self,infolder=os.getcwd(),outfolder=None, samp_regex='^B_((K[0-9]{6})|([0-9]{3}-[0-9]{5}))_[0-9]{2}',append=True,progress="project_progress.txt",debug=1):
		self.__inpath = infolder
		self.__outpath = outfolder		
		self.__debug = debug
		self.__pat = samp_regex
		self.__app = append
		self.__logfile = progress
		self.__ow_chroms = 0
		#added this code on 15 August 13
		#if appending to an already existing project
		# the progress file is a text file containing the name of already processed runs
		# one per line
			
		div()
		if self.__app:
			print "You have selected to append to an existing project...\n"
			prog_f = pp.open_file2read(self.__logfile)
			skip_runs = [line.strip() for line in prog_f]
			pp.close_file(prog_f)
			print "A total of {} run(s) will be skipped.".format(len(skip_runs))
			self.__skip_runs = r"|".join(skip_runs)
		else:
			print "No project to append to..."	
			self.__skip_runs = []
		
		div()		
	
		self.__ab1_files()
		
		div()	
	
		pattern = re.compile(self.__pat)

		self.__samples(search_pat=pattern,k=self.ab1.keys())
		
		self.__samp_file_dic(samples=self.sample_id,files_dic=self.ab1)

		div()
	
		self.__stage()
		
		sys.exit()
		print "Running phredPhrap..."
		print ""
		try:
			self.__proc(outfolder=outfolder)
		except:
			print "Failed to finish processing the samples"
		
		#return to running directory
		os.chdir(self.path)

	
	def __ab1_files(self):
		"""Return a dictionary with filename as key, and path as values"""
		print "Searching "+self.__inpath+" for ab1 files...\n"
		self.ab1 = {}
		for root,dirs,files in os.walk(self.__inpath):
			if self.__app:
				for d in dirs:
					if d in self.__skip_runs:
						dirs.remove(d)
			for f in files:
				if(re.search("ab1",f)):
					self.ab1[f]=root+"/"+f
		print "Found {} files.".format(len(self.ab1.keys()))
	
	#added this code on 13 August 2013 as part of v1
	def __samples(self,search_pat,k):
		"""Return a list of sample ids in the file given some sample_regex"""
		print "Checking if all files match the regex...\n"
		pat_check = [key for key in k if search_pat.match(key) == None]
		if len(pat_check) > 0:
			print "A total of {} files did not match the regex.".format(len(pat_check))
			print "The files are:"
			for i in pat_check:
				print i
			print "Please check your regex, or fix the files."
			sys.exit()
		else:
			print "All files were matched...\n"
			sample_id = list(set([search_pat.match(key).group() for key in k]))
			print "A total of {} samples were found in {} files.".format(len(sample_id),len(k))
			self.sample_id = sample_id

	#added on 15 August 2013
	def __samp_file_dic(self,samples,files_dic):
		f_key = files_dic.keys()
		res = [[files_dic[k] for k in f_key if re.search(pat,k) != None] for pat in samples]
		self.sf_dic = {}
		for i in range(len(samples)):
			self.sf_dic[samples[i]] = res[i]
	
	#added on the 15 August 2013
	def __stage(self):
		div()		
		for s in self.sf_dic.keys():
 			try:
				dir = os.path.join(self.__outpath,s)
				os.mkdir(dir)
				for sub_dir in ['chromat_dir','phd_dir','edit_dir','poly_dir']:
					os.mkdir(os.path.join(dir,sub_dir))
				for f in self.sf_dic[s]:
					src = f
					fn = f.split("/")[-1]
					dest = os.path.join(dir,'chromat_dir',fn)
					shutil.copyfile(src,dest)
			except:
				for f in self.sf_dic[s]:
					src = f
					fn = f.split("/")[-1]
					dest = os.path.join(self.__outpath,s,'chromat_dir',fn)
					if os.path.isfile(dest):
						if self.__ow_chroms!=2:
							if self.__overwrite_chromat(dest):
								shutil.copyfile(src,dest)
							else:
								break
						else:
							shutil.copyfile(src,dest)
					else:
						shutil.copyfile(src,dest)
		div()

	def __overwrite_chromat(self,sample):
		if self.__ow_chroms == 0:
			attempts = 0
			while attempts < 5:
			
				print "You are about to overwrite {}. Are you ok with this?".format(sample)
				ans = raw_input("Press: 0 to skip; 1 to overwrite this specific file; 2 to overwrite all samples; 3 to skip all overwrites: ")
				if int(ans) in [0,1,2,3]:
					self.__ow_chroms=int(ans)
					return self.__ow_chroms
				else:
					attempt += 1
		elif self.__ow_chroms == 1:
			self.__ow_chroms = 0
			self.__overwrite_chromat(sample)
		elif self.__ow_chroms == 3:
			return 0
		else:
			raise Exception("Don't know what to do with your options to overwrite. Exiting....")	
	
	
	def __proc(self):
		h5_filename = os.path.join(self.__outpath,"reports.h5")
		h5_report = open_file(h5_filename,mode="w",title="Sequence Report")
		read_group = h5_report.create_group("/",'reads','Reads report')
		contig_group = h5_report.create_group("/",'contigs','Contigs report')
		read_table = h5_report.create_table(read_group,'reads_qc',Reads,"Read Quality Control")
		contigs_table = h5_report.create_table(contig_group,'contig_info',Contigs, "Contig information")
		outjunk = open(tmp_path+"/"+"junk.fasta",'w')
		outstdout = open(tmp_path+"/"+"stdout.txt",'w')
		try:
			for samp in self.sample_id:
				div()
				print "Processing sample: {}.".format(samp)
				os.chdir(os.path.join(self.__output,samp,"edit_dir"))
				subprocess.call(['phredPhrap'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
				print "Done..."
				div()
				print "Writing reads QC table results"
			
				read_gen = SeqIO.parse(open(samp+".fasta","r"),"fasta")
				qual_gen = SeqIO.parse(open(samp+".fasta.screen.qual","r"),"qual")
			
				for r,q in zip(read_gen,qual_gen):
					read_row_constructor(r,q,read_table,self.ab1)

				ace_file = pick_latestAce(".")
				ace_gen = SeqIO.parse(open(ace_file,'r'),'ace')
				try:
					contig = ace_gen.next()
					contig.id = samp
					contig_row_constructor(contig,contigs_table,samp)
					SeqIO.write(contig,outjunk,"fasta")
				except:
					print "No contig available"
				dic()
				print "\n"
		except:
			h5_report.close()
			print "Something went wrong"
			raise
		h5_report.close()
