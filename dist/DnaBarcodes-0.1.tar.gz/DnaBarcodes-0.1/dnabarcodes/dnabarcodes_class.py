#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
A class for storing Barcode objects, and querying them
'''
import sys
import os
import csv
import datetime
import re

#import ZODB functions
from ZODB.FileStorage import FileStorage
from ZODB.DB import DB
import transaction

#import biopython modules
from Bio import SeqIO

#local methods
from dnabarcodes import parameter_parser as pp
from dnabarcodes import blasting as bl
from dnabarcodes import reporting as rp
from dnabarcodes.sample_class import Barcode
from dnabarcodes import dbcodeConfig

class DNABarcodes:
    def __init__(self,cfg):
        if isinstance(cfg,str):
            self.args = dbcodeConfig.read(cfg)
        else:
            self.args = cfg
        self.db_file = os.path.join(self.args.get('metadata','home_folder'),self.args.get('metadata','dbcodes_db'))
        if os.path.isfile(self.db_file):
            self.open()
        else:
            self.create()
        db = DB(self.store)
        connection = db.open()
        self.samples = connection.root()
        self.append = self.args.getboolean('metadata','append')

    def parse_parameters(self,paramfile):
        return pp.parse_param(paramfile)

    def open(self):
        print "Opening barcode database".ljust(80,".")
        store_fn = open(self.db_file)
        self.store = FileStorage(self.db_file)

    def create(self):
        print "Creating barcode database".ljust(80,".")
        if os.path.isfile(self.db_file):
            os.unlink(self.db_file)
        self.store = FileStorage(self.db_file)

    def close(self):
        self.store.close()

    def sync(self):
        '''
        Add new samples to the database
        '''
        curr_chroms = {}
        new_chroms = {}

        curr_time = datetime.datetime.utcnow()

        if self.args.getboolean('metadata','copy_phd'):
            curr_phd = {}
            new_phd = {}
            for k in self.samples:
                curr_chroms[k] = self.samples[k].chromats
                curr_phd[k] = self.samples[k].phd_files
        else:
            for k in self.samples:
                curr_chroms[k] = self.samples[k].chromats


        for root,dirs,files in os.walk(self.args.get('metadata','traces_folder')):
            for fn in files:
                f = os.path.join(root,fn)
                if re.search(self.args.get('metadata','trace_ext'),f):
                    mat = re.search(self.args.get('metadata','regex'),f)
                    if mat == None:
                        continue
                    elif mat.group() in curr_chroms:
                        if f in curr_chroms[mat.group()]:
                            continue
                        elif f not in curr_chroms[mat.group()] and mat.group() not in new_chroms:
                            new_chroms[mat.group()] = set([f])
                        else:
                            new_chroms[mat.group()].update([f])
                    else:
                        if mat.group() not in new_chroms:
                            new_chroms[mat.group()] = set([f])
                        else:
                            new_chroms[mat.group()].update([f])

                elif self.args.getboolean('metadata','copy_phd') and re.search('phd',f):
                    mat = re.search(self.args.get('metadata','regex'),f)
                    if mat == None:
                        continue
                    elif mat.group() in curr_phd:
                        if f in curr_phd[mat.group()]:
                            continue
                        if f not in curr_phd[mat.group()] and mat.group() not in new_phd:
                            new_phd[mat.group()] = set(f)
                        else:
                            new_phd[mat.group()].update([f])
                    else:
                        if mat.group() not in new_phd:
                            new_phd[mat.group()] = set([f])
                        else:
                            new_phd[mat.group()].update([f])
                else:
                    continue

        proc_folder = self.args.get('metadata','barcodes_folder')

        #update old samples
        for k in set(new_chroms.keys()).intersection(self.samples):
            if not self.args.getboolean('metadata','copy_phd') or k not in new_phd:
                self.samples[k].update_chromat(new_chroms[k])
            else:
                self.samples[k].update_chromat(new_chroms[k],new_phd[k])
            self.samples[k].stage(self.append,self.args.getboolean('metadata','copy_phd'))
            self.samples[k].timestamps['chromats'] = curr_time
        transaction.commit()

        #add new samples
        for k in set(new_chroms.keys()).difference(self.samples):
            if not self.args.getboolean('metadata','copy_phd') or k not in new_phd:
                print 'Adding sample {}'.format(k)
                self.samples[k] = Barcode(proc_folder,k,new_chroms[k])
            else:
                print 'Adding sample {}'.format(k)
                self.samples[k] = Barcode(proc_folder,k,new_chroms[k],new_phd[k])

            self.samples[k].stage(self.append,self.args.getboolean('metadata','copy_phd'))
            self.samples[k].timestamps['chromats'] = curr_time
        transaction.commit()

        #run through tasks
        os.system('clear')
        if self.args.getboolean('tasks','run_phredphrap'):
            print '#'*40
            print 'Starting Phred, Phrap, PolyPhred pipeline'
            self.do_phredPhrap()
        if self.args.getboolean('tasks','run_wwwBlast'):
            os.system('clear')
            print '#'*40
            print 'Starting NCBI BLAST...'
            self.do_wwwBlast()
            self.output_csv_wwwBlast()
        if self.args.getboolean('tasks','run_localBlast'):
            os.system('clear')
            print '#'*40
            print 'Starting local BLAST...'
            self.do_localBlast()
            self.output_csv_localBlast()
        if self.args.getboolean('tasks','correct_readingFrame'):
            os.system('clear')
            print '#'*40
            print 'Identifying barcode frames...'
            self.do_localBlastX()
        if self.args.getboolean('reports','out_barcodes'):
            os.system('clear')
            print '#'*40
            print 'Outputting Barcodes...'
            self.output_barcodes(phylo=self.args.getboolean('tasks','correct_readingFrame'))
        os.system('clear')
        print '#'*40
        print 'Outputting reports...'
        self.read_quality_reports()
        self.barcode_quality_report()
        os.system('clear')
        print 'DnaBarcodes has successfully finished.'
        self.close()

    # def update(self,records):
    #     '''
    #     Add new chromatograms to existing records
    #     '''
    #     cur_time = datetime.datetime.utcnow()
    #     for k in set(self.samples.keys()).intersection(records):
    #         if self.samples[k].chromats == records[k]:
    #             pass
    #         else:
    #             self.samples[k].update_chromats(records[k])
    #             self.samples[k].stage(self.append)
    #             self.samples[k].timestamps['chromats'] = cur_time
    #     transaction.commit()

    def do_phredPhrap(self):
        '''
        Perform phredPhrap analysis, but only for those that have been recently added (phrep_phrap timestamp is 0) or updated (phrep_phrap timesamp is older than the current chromats timestamp)
        '''
        cur_time = datetime.datetime.utcnow()
        for k in self.samples.keys():
            pp_cur_time = self.samples[k].timestamps['phred_phrap']
            ch_cur_time = self.samples[k].timestamps['chromats']
            if pp_cur_time == 0:
                self.samples[k].phred_phrap(self.args.get('tasks','vector_db'))
                self.samples[k].timestamps['phred_phrap']=cur_time
            elif ch_cur_time > pp_cur_time:
                self.samples[k].phred_phrap(self.args.get('tasks','vector_db'))
                self.samples[k].timestamps['phred_phrap']=cur_time
            else:
                pass
        transaction.commit()

    def do_wwwBlast(self):
        '''
        Blast each available DNA barcode against one of the online NCBI databases
        '''
        cur_time = datetime.datetime.utcnow()
        for k in self.samples.keys():
            print 'Processing sample: {}'.format(k)
            bwww_cur_time = self.samples[k].timestamps['blast_www']
            pp_cur_time = self.samples[k].timestamps['phred_phrap']
            #check if barcode exists
            if self.samples[k].barcode != 0:
                #check if blast has already beed done
                #if not, do it
                if bwww_cur_time == 0:
                    self.samples[k].blast_www(self.args.get('tasks','wwwBlast_flavour'),self.args.get('tasks','wwwBlast_db'))
                    self.samples[k].timestamps['blast_www'] = cur_time
                # if so, only redo if phredPhrap has been run more recently
                elif pp_cur_time > bwww_cur_time:
                    self.samples[k].blast_www(self.args.get('tasks','wwwBlast_flavour'),self.args.get('tasks','wwwBlast_db'))
                    self.samples[k].timestamps['blast_www'] = cur_time
                #else do nothing
                else:
                    pass
            #else do nothing
            else:
                pass
        transaction.commit()


    def do_localBlast(self):
        '''
        Blast each available DNA barcode against against a local barcode database
        '''
        cur_time = datetime.datetime.utcnow()
        for k in self.samples.keys():
            print 'Processing sample: {}'.format(k)
            blocal_cur_time = self.samples[k].timestamps['blast_local']
            pp_cur_time = self.samples[k].timestamps['phred_phrap']
            #check if a barcode exits
            if self.samples[k].barcode != 0:
                #check if local blast has been done
                # if not, do it
                if blocal_cur_time == 0:
                    self.samples[k].blast_local(self.args.get('tasks','localBlast_db'))
                    self.samples[k].timestamps['blast_local'] = cur_time
                #if so, only redo if phredPhrap has been run more recently
                elif pp_cur_time > blocal_cur_time:
                    self.samples[k].blast_local(self.args.get('tasks','localBlast_db'))
                    self.samples[k].timestamps['blast_local'] = cur_time
                #else, do nothing
                else:
                    pass
            #else, do nothing
            else:
                pass
        transaction.commit()

    def do_localBlastX(self):
        '''
        Blast each available DNA barcode across all six possible reading frames against a local reference protein sequence database. The goal is to establish the reading-frame of the barcode. The output will be used when outputting barcodes for phylogenetic analysis. All barcodes will outputted in the same frame, and starting from the first base of the first codon.
        '''
        cur_time = datetime.datetime.utcnow()
        for k in self.samples.keys():
            print 'Processing sample: {}'.format(k)
            blocal_cur_time = self.samples[k].timestamps['blast_local']
            bxlocal_cur_time = self.samples[k].timestamps['blastx_local']
            #check if a barcode exits
            if self.samples[k].barcode != 0:
                #check if local blast has been done
                # if not, do it
                if blocal_cur_time == 0:
                    self.samples[k].blast_local(self.args.get('tasks','localBlast_db'))
                    self.samples[k].timestamps['blast_local'] = cur_time
                if bxlocal_cur_time == 0:
                    self.samples[k].blast_local(self.args.get('tasks','localBlastX_db'),blastx=True)
                    self.samples[k].timestamps['blastx_local'] = cur_time
                #if so, only redo if phredPhrap has been run more recently
                elif blocal_cur_time > bxlocal_cur_time:
                    self.samples[k].blast_local(self.args.get('tasks','localBlastX_db'),blastx=True)
                    self.samples[k].timestamps['blastx_local'] = cur_time
                #else, do nothing
                else:
                    pass
            #else, do nothing
            else:
                pass
        transaction.commit()


    def output_barcodes(self,phylo=None):
        '''
        Cycle through all entries in the database with a barcode, and output these to a file with a user specified format.

        The default format is 'fasta'.

        The optional minQP sets a minimum proportion of bases with a phred quality score of minQ or more.

        Default value is 0, where all contigs are outputted.
        '''
        outfile = os.path.join(self.args.get('metadata','reports_folder'),self.args.get('metadata','project_basename')+'_'+self.args.get('reports','bcode_fname')+'.'+self.args.get('reports','bcode_format'))
        format = self.args.get('reports','bcode_format')
        minQ = self.args.getint('reports','bcode_minQ')
        minQP = self.args.getfloat('reports','bcode_minQP')
        tmp = open(outfile,'w')
        bcodes = []
        for k in self.samples.keys():
            print "Processing sample: {}".format(k)
            if self.samples[k].barcode != 0:
                tmp_seq = self.samples[k].barcode
                qual_scores = tmp_seq.letter_annotations['phred_quality']
                len_seq = float(len(tmp_seq.seq))
                obs_proportion_Q = sum(map(lambda x: 1 if x >= minQ else 0,qual_scores))/len_seq
                description = '|'
                if self.samples[k].timestamps['blast_local']!=0: 
                    if self.samples[k].blast_local_top_hit['query_id']!='?':
                        description = description + "[Local database accession=" + self.samples[k].blast_local_top_hit['accession'] +"]"
                if self.samples[k].timestamps['blast_www']!=0:
                    if len(description)>1:
                        description = description + " [NCBI Blast accession=" + self.samples[k].blast_www_top_hit['accession'] +"] [NCBI Blast Taxon=" + self.samples[k].blast_www_top_hit['taxon']+"]"
                    else:
                        description = description + " [NCBI Blast accession=" + self.samples[k].blast_www_top_hit['accession']+"]"
                if len(description)>1:
                    description = description + ' [Proportion bases with Phred quality score >= {}='.format(minQ) + str(obs_proportion_Q)+"]"
                else:
                    description = description + ' [Proportion bases with Phred quality score >= {}: '.format(minQ) + str(obs_proportion_Q)+"]"
                if phylo == True:
                    if self.samples[k].timestamps['blastx_local']!=0:
                        frame = self.samples[k].blast_local_top_hit['frame']
                        if frame == 1:
                            tmp_seq
                        elif frame > 1:
                            tmp_seq = tmp_seq[(frame-1):]
                        elif frame < 0:
                            tmp_seq= tmp_seq.reverse_complement()
                            tmp_seq = tmp_seq[(-1*frame)-1:]
                            tmp_seq.id = k
                self.samples[k].barcode.description = description
                tmp_seq.description = description
                if obs_proportion_Q >= minQP:
                    bcodes.append(tmp_seq)
                else:
                    continue
        SeqIO.write(bcodes,tmp,format)
        tmp.close()

    def read_quality_reports(self):
        '''
        This function outputs three files for each run folder found in the RawData folder:
            1. Reads report:
                The goal: To quickly gauge the quality of the raw data and primers
                The information: Each column contains counts of reads belonging to a particular sequencing primer (assuming two primers, the table has two columns of data). Each row has counts of reads falling into a quality category of 'high', 'acceptable', 'low', or 'failed' (see point 3 for thresholds).
            2. Samples report:
                The goal: To quickly gauge the quality of the templates and primers
                The information: A two way table, cross-referencing the counts of templates falling within a particular quality category ('high','acceptable','low','failed') in each primer. So, assuming two primers, the left uppermost cell of the table willh have the total count of templates for which both 'forward' and 'reverse' read are are labelled 'high' quality. Thus, it is possible to see if a primers is performing better than another.
            3. Summary report:
                The goal: Pinpoint template/primer pairs that should be redone
                The information: Each row contains information pertaining to a single template. The assumption is that the template has been sequenced in both directions (two primers). For each template/primer pair, information on length and proportion of bases ≥Q20 are displayed, along with a quality category of 'high','acceptable','low', and 'failed'. The scores relate to the proportion of bases with a ≥Q20. Currently, 'high' is proportionQ20≥0.975, 'acceptable' is 0.95≤proportionQ20<0.975, 'low' is 0 < proportionQ20 < 0.95, and 'failed' is proportionQ20 = 0.

        Each file is named with a project name and run ID prefix, followed by an appropriate suffix:
            1. _reads_report.csv
            2. _samples_report.csv
            3. _summary_report.csv

        For example, the reads report file for the following project and run would be:
            project name: myproject
            run ID: myrun01
            filename: myproject_myrun01_reads_report.csv
        '''
        outfile = os.path.join(self.args.get('metadata','reports_folder'),self.args.get('metadata','project_basename'))
        runs = set()
        [runs.update(self.samples[k].runs) for k in self.samples.keys()]
        for rn in runs:
            fn_reads = outfile+'_'+str(rn)+'_reads_report.csv'
            fn_samples = outfile+'_'+str(rn)+'_samples_report.csv'
            fn_summary = outfile+'_'+str(rn)+'_summary_report.csv'
            
            fh_reads = open(fn_reads,'w')
            fh_samples = open(fn_samples,'w')
            fh_summary = open(fn_summary,'w')
            
            fw_reads = csv.writer(fh_reads,csv.QUOTE_MINIMAL,delimiter=',')
            fw_samples = csv.writer(fh_samples,csv.QUOTE_MINIMAL,delimiter=',')
            fw_summary = csv.writer(fh_summary,csv.QUOTE_MINIMAL,delimiter=',')
            header = ['templateID','primer1','readLength_primer1','proportion_basesQ20+_primer1','primer2','readLength_primer2','proportion_basesQ20+_primer2']
            summary_data=[]
            fw_summary.writerow(header)
            for s in self.samples.keys():
                try:
                    tmp = self.samples[s].read_sum[rn]
                    templates = set([temp[0] for temp in tmp])
                    primers = list(set([temp[1] for temp in tmp]))
                    primers.sort()
                    for template in templates:
                        row = [template]
                        row.extend([rec[1:] for rec in tmp if rec[1]==primers[0]][0])
                        row.extend([rec[1:] for rec in tmp if rec[1]==primers[1]][0])
                        summary_data.append(row)
                except:
                    pass
            fw_summary.writerows(summary_data)
            rp.summary_tables(summary_data,fw_reads,fw_samples)
            fh_reads.close()
            fh_samples.close()
            fh_summary.close()

    def barcode_quality_report(self):
        outfile = os.path.join(self.args.get('metadata','reports_folder'),self.args.get('metadata','project_basename')+'_barcode_qc_summary.csv')
        minQ = self.args.getint('reports','bcode_minQ')
        fh = open(outfile,'w')
        fw = csv.writer(fh,csv.QUOTE_MINIMAL,delimiter=',')
        header = ['sampleID','numberReads','barcodeLength','proportionQ20+','countAmbiguousBases']
        fw.writerow(header)
        bcodes = []
        for k in self.samples.keys():
            if self.samples[k].barcode != 0:
                qual_scores = self.samples[k].barcode.letter_annotations['phred_quality']
                len_seq = float(len(self.samples[k].barcode.seq))
                obs_proportion_Q = sum(map(lambda x: 1 if x >= minQ else 0,qual_scores))/len_seq
                ambiguous_bases = str(self.samples[k].barcode.seq).count('-')
                n_reads = len(self.samples[k].chromats)
                bcodes.append([k,n_reads,len_seq,obs_proportion_Q,ambiguous_bases])
        fw.writerows(bcodes)
        fh.close()

    def output_csv_localBlast(self):
        '''
        Output a CSV file with local Blast results for all available barcodes in the database.

        Each row will be top hit Blast information for a single entry in the database.
        '''
        outfile = os.path.join(self.args.get('metadata','reports_folder'),self.args.get('metadata','project_basename')+'_'+'localBlast_report.csv')
        try:
            outf_hand = open(outfile,'w')
        except:
            print "Could not open file {}.".format(outfile)
            raise
        
        records = [self.samples[k].blast_local_top_hit for k in self.samples.keys() if self.samples[k].barcode != 0 and self.samples[k].timestamps['blast_local']!=0]

        outf_writer = csv.writer(outf_hand,delimiter=",",quoting=csv.QUOTE_MINIMAL)

        records_sort = bl.multikeysort(records,['-percent_identity','-alignment_length'])

        header = ['sampleID','localdb_ID','completeMatch','percentIdent','genus','genbankAcc','numberMatches','lengthAlign','bitScore','eValue']
        outf_writer.writerow(header)

        lines = []
        for rec in records_sort:
            line = []
            line.append(rec['query_id'])
            tmp = rec['accession'].split("|")
            line.append(tmp[0])
            if rec['percent_identity'] == 100.0:
                line.append('Yes')
            else:
                line.append('No')
            line.append("{:0.2f}".format(rec['percent_identity']))
            line.append(rec['taxon'])
            line.append(rec['genbank'])
            line.append(rec['number_identity'])
            line.append(rec['alignment_length'])
            line.append(rec['bit_score'])
            line.append("{:0.2f}".format(rec['evalue']))
            lines.append(line)
        outf_writer.writerows(lines)
        outf_hand.close()

    def output_csv_wwwBlast(self):
        outfile = os.path.join(self.args.get('metadata','reports_folder'),self.args.get('metadata','project_basename')+'_'+'wwwBlast_report.csv')
        fh = open(outfile,'w')
        fw = csv.writer(fh,delimiter=",",quoting=csv.QUOTE_MINIMAL)
        header = ['sampleID','percentIdent','taxon','genbankAcc','bitScore','eValue']
        records = []
        for k in self.samples.keys():
            if self.samples[k].barcode != 0 and self.samples[k].timestamps['blast_www']!=0:
                tmp = []
                rec = self.samples[k].blast_www_top_hit
                tmp.append(k)
                tmp.append(rec['percent_identity'])
                tmp.append(rec['taxon'])
                tmp.append(rec['accession'])
                tmp.append(rec['bit_score'])
                tmp.append(rec['evalue'])
                records.append(tmp)
        fw.writerow(header)
        fw.writerows(records)
        fh.close()

    def output_mash_localwwwBlast(self):
        outfile = self.args.get('metadata','project_basename')+'_'+'mash_local_wwwBlast_report.csv'
        fh = open(outfile,'w')
        fw = csv.writer(fh,delimiter=",",quoting=csv.QUOTE_MINIMAL)
        header = ['sampleID','percentIdent','taxon','genbankAcc','bitScore','eValue']

    def reset_timestamps(self,stamp,samples='all'):
        if samples == 'all':
            samples = self.samples.keys()
        if stamp not in set(['chromats','phred_phrap','blast_local','blast_www','contig']):
            raise Exception('{} not found among the possible timestamps {}'.format(stamp,set(['chromats','phred_phrap','blast_local','blast_www','contig'])))
        for k in samples:
            self.samples[k].timestamps[stamp]=0


