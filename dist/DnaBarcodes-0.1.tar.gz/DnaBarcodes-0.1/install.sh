#!/bin/sh
# a script to install DNABarcodes

#load necessary functions
source install_functions.sh

#check if super users
check_sudo

#run main function
main $@