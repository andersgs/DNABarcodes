#!/usr/bin/env python
"""
DNABarcodeReader parameter file parser
"""
import sys,subprocess,os,codecs,re
###############################################################################
###### File and path handling functions  ######################################
###############################################################################

#importing the information from the parameter file
def filter_out_comments(line):
	if line[0] != "#" and line.strip() != "":
		d1 = [el.strip() for el in line.split('=')]
		return d1

#open files to read, exit the program if for some reason cannot create/open the file
def open_file2read(filename):
	try:
		f=codecs.open(filename, mode='r',encoding='utf-8')
		return f
	except:
		print "Could not open file {}".format(filename)
		raise

#open files to write, exit the program if for some reason cannot create/open the file		
def open_file2write(filename):
	try:
		f=codecs.open(filename,mode='w',encoding='utf-8')
		return f
	except:
		print "Could not open file {}\n".format(filename)
		raise

#close files nicely
def close_file(file_handle):
	file_handle.close()

#check if a file is valid, and if so, return the absolute path to the file.
# Exit the program if the path to the file is not valid
def validate_file(path):
	if os.path.exists(os.path.abspath(path)):
		return os.path.abspath(path)
	else:
		raise OSError("File {} does not exist.\n".format(path))

#check if a path to a directory is valid, and if so, return the absolute path. 
# Exit the program if the path is not valid
def validate_dir(path):
	if os.path.exists(os.path.abspath(path)):
		return os.path.abspath(path)
	else:
		raise OSError("Directory {} does not exist.\n".format(path))

#Try to create a directory, and return the absolute path.
#  If it already exists, return the absolute path to the directory.
#  Exit the program with an error if can't create nor can find the directory.
def create_dir(path):
	try:
		os.mkdir(path)
		return os.path.abspath(path)
	except:
		try:
			d=validate_dir(path)
			return os.path.abspath(d)
		except:
			raise OSError("Could not create nor open {}.".format(path))

# issue the user with a warning before cleaning out the processing directory
def wipe_warning(proc_dir):
	stp = 0
	print '#'*80
	print '#'*10 + ' CAUTION! CAUTION! CAUTION! ' + '#'*42
	print '#'*80
	
	while stp < 5:
		ans = raw_input("You chose to NOT append to an existing project. If you continue\nall subdirectories and files in {}, if they exist, will be DELETED.\nTo continue type 'y' followed by <enter>.\nTo stop and change the parameter file type 'n' followed by 'enter':\n".format(proc_dir))
		if ans == 'y':
			print '#'*80
			return
		elif ans == 'n':
			print '#'*80		
			sys.exit("You must change the parameter file to proceed.\n")
			#raise OSError("You must change the parameter file to proceed.")
		else:
			stp += 1
	print "You must type 'y' or 'n'. Please check your parameter file, and start again.\n"
	print '#'*80
	raise OSError("Could not decide on what to do based on your answers.\n")		 

#delete all files and subdirectories in the path. Used to clean the processing directory.
def clean_dir(path):
	if os.path.ismount(path):
		raise OSError("Deleting all subdirectories and files from {} will potentially destroy your computer. Don't do it.\n".format(path))
	else:
		#Code from http://docs.python.org/2/library/os.html
		for root, dirs, files in os.walk(path, topdown=False):
			for name in files:
				os.remove(os.path.join(root, name))
			for name in dirs:
				os.rmdir(os.path.join(root, name))
				

###############################################################################
###### Parameter handling and validation functions  ###########################
###############################################################################

#create a dictionary with parameter:value pairs
def dict_creator(key_values):
	return dict([(key,value) for key,value in key_values])
	
#for parameters that have a boolean value, make sure they are appropriate values
# and update the dictionary so that str is substituted with a bool
def bool_checker(key,dict):
	if dict[key].find("True") is 0:
		 dict[key]=bool(1)
	elif dict[key].find("False") is 0:
		dict[key]=bool(0)
	else:
		raise TypeError("The parameter {} must be True or False. {} is not acceptable.".format(key,dict[key]))
	return dict
	
#check the file regular expression to see if it works
def validate_regex(pat,raw_data_path,chrom_type):
	fnames = []
	for root,dirs,files in os.walk(raw_data_path):
		for f in files:
			if re.search(chrom_type,f):
				fnames.append(os.path.join(root,f))
	count = 0
	for f in fnames:
		if re.search(pat,f):
			count += 1
	if count == 0:
		raise Exception("The pattern {} does not seem to match any files in {}.\nPlease check your expression using a regex tester online.".format(pat,raw_data_path))
	return count

#used to transform any numerical value from str to float
def to_float(value):
	try:
		val = float(value)
		return val
	except:
		raise TypeError("Could not transform {} = {} into a floating number.".format(param,dict[param]))

#check that the minimum QC value to append a contig to the FASTA file is within [0,1]
def min_qc_value(value):
	if value < 0.0:
		raise TypeError("Minimum QC value to append contig to FASTA file is smaller than zero.")
	elif value > 1.0:
		raise TypeError("Minimum QC value to append contig to FASTA file is larger than one.")
	else:
		return

#make sure the program exe exists, and can be run
# used to make sure that phedPhrap.pl and local blast programs are installed locally		
def is_exe(exe):
	try:
		subprocess.Popen(exe,stderr=subprocess.PIPE,stdout=subprocess.PIPE)
		return True
	except:
		raise NameError("Could not find the program {}".format(exe))

#make sure that the NCBI Blast program and database are acceptable for the program
# Exit the program if the Blast program and/or database are not valid.
# Valid programs are specified in the list 'valid_progs'
# Valid databases are specified in the list 'valid_db'
def validate_ncbi_blast(program,database):
	#valid programs taken from here: http://www.ncbi.nlm.nih.gov/BLAST/blast_program.shtml
	# only nucleotide based programs allowed at the moment
	valid_progs = ['blastn','tblastx']
	
	#valid databases taken from here: http://www.ncbi.nlm.nih.gov/BLAST/blast_databases.shtml
	# only nr and refseq allowed at the moment
	valid_db = ['nr','refseq']
	
	if program not in valid_progs:
		print "Valid NCBI BLAST programs are:\n"
		for prog in valid_progs:
			print prog
		raise NameError("BLAST program {} is not among the valid programs.\n".format(program))
		
	if database not in valid_db:
		print "Valid NCBI BLAST databases are:"
		for db in valid_db:
			print db
		raise NameError("BLAST database {} is not among the valid databases.\n".format(database))
		
	return

###############################################################################
###### The main parsing function  #############################################
###############################################################################

def parse_param(paramfile):
	#check if we can open the parameter file
	print('Looking for parameter file'.ljust(76,".")),
	f = open_file2read(paramfile)
	print 'OK'
	
	#read in the parameters from the file, and parse out comment lines
	print('Reading parameters'.ljust(76,".")),
	params = []
	for line in f:
		tmp=filter_out_comments(line)
		if tmp != None:
			params.append(tmp)
	p_dic = dict_creator(params)
	print 'OK'
	
	#checking and parsing boolean arguments
	print('Checking boolean parameters'.ljust(76,".")),
	for arg in ['run_localBlast','append','run_NCBIBlast','run_phredPhrap','run_staging','output_barcodes_file','out_contig_HTML','out_read_HTML','copy_phd']:
		p_dic = bool_checker(arg,p_dic)
	print 'OK'
	
	#checking if running the staging task, and if so:
	# check if rawdata directory exists and is valid
	# check if the file name search pattern exists and is valid
	# check if appending to an existing project. If so:
	#	check if log file exists and can be open
	#	check if the processing folder exists and can be open
	# If not appending to existing project:
	#	check if processing directory exists. If it does:
	#		Issue user with warning that it will be wiped clean
	#		If user ok, wipe the processing directory
	#	if processing directory does not exist, create one
	print('Checking if running staging'.ljust(76,".")),
	if p_dic['run_staging']:
		print 'Yes'

		print('		Checking for working directory'.ljust(62,".")),
		#check location of raw data
		p_dic['work_dir'] = create_dir(p_dic['work_dir'])
		print 'OK'
	
		print('		Checking for raw data directory'.ljust(62,".")),
		#check location of raw data
		p_dic['raw_data'] = os.path.join(p_dic['work_dir'],p_dic['raw_data'])
		p_dic['raw_data'] = create_dir(p_dic['raw_data'])
		print 'OK'

		print('		Checking for reports directory'.ljust(62,".")),
		#check location of reports
		p_dic['reports_dir'] = os.path.join(p_dic['work_dir'],p_dic['reports_dir'])
		p_dic['reports_dir'] = create_dir(p_dic['reports_dir'])
		print 'OK'

		print('		Checking search pattern'.ljust(62,".")),
		#check if the search pattern finds any files in the raw data directory
		succ_matches=validate_regex(p_dic['file_search'],p_dic['raw_data'],p_dic['chrom_type'])
		print 'OK'
	
		print('			Total files found with the pattern'.ljust(55,".")),
		print "{}".format(succ_matches)

		#check if copying phd files
		print('		Checking if copying phd files'.ljust(62,".")),
		if p_dic['copy_phd']:
			print 'Yes'

			succ_phd=validate_regex(p_dic['file_search'],p_dic['raw_data'],'phd')

			print('			Total files found with the pattern'.ljust(55,".")),
			print "{}".format(succ_phd)
		else:
			print 'No'


	
		print('		Checking if apending to existing project'.ljust(62,".")),
		#are we appending:
		if p_dic['append']:
			print 'Yes'
		
			print('			Looking for database file'.ljust(55,".")),
			#check for log file
			p_dic['database_store'] = os.path.join(p_dic['work_dir'],p_dic['database_store'])
			#p_dic['database_store'] = validate_file(p_dic['database_store'])
			print 'OK'
		
			print('			Checking processing folder'.ljust(55,".")),
			#check if seqs path exits
			p_dic['processing_folder'] = os.path.join(p_dic['work_dir'],p_dic['processing_folder'])
			p_dic['processing_folder'] = create_dir(p_dic['processing_folder'])
			print 'OK'
			
			# print('			Checking fasta file'.ljust(55,".")),
			# #check if fasta file exists
			# p_dic['fasta_filename'] = validate_file(os.path.join(p_dic['processing_folder'],p_dic['fasta_filename']))
			# print 'OK'


		else:
			print 'No'
			
			print ' '		
			print('			Create/clear processing directory'.ljust(55,".")),
			#checking processing dir	
			p_dic['processing_folder'] = os.path.join(p_dic['work_dir'],p_dic['processing_folder'])
			p_dic['processing_folder'] = create_dir(p_dic['processing_folder'])
			
			#report file location
			#p_dic['report_filename'] = os.path.join(p_dic['processing_folder'],p_dic['report_filename'])
			
			#fasta file location
			#p_dic['barcode_filename'] = os.path.join(p_dic['processing_folder'],p_dic['barcode_filename'])

					
		#as we are not appending, check if dir is empty, and delete any files/folder
		# within
			if os.listdir(p_dic['processing_folder']):

				print('			Checking of user ok with wiping processing directory'.ljust(55,"."))
				#issue warning to user
				wipe_warning(p_dic['processing_folder'])
				print ' '
			
				clean_dir(p_dic['processing_folder'])
			print 'OK'
	else:
		print 'No'

	print('Checking if running phredPhrap'.ljust(76,".")),
	#if running phredPhrap.pl, check if the program exists
	if p_dic['run_phredPhrap']:
		print 'Yes'
		print('		Checking if phredPhrap.pl exists'.ljust(62,".")),
		is_exe(p_dic['phredPhrap_path'])
		print 'OK'
	else:
		print 'No'
		#If not running phredPhrap, must make sure that staging is not run either.
		# Otherwise, it does make sense to have staged chromatograms, 
		# and not run phredPhap to analyse them
		if p_dic['staging']:
			raise Exception("You have requested to run staging,\nyet you are not running phredPhrap. Please check your parameter file.")
	
	
	
	#check if outputting a fasta file
	print('Checking if outputting a barcode sequence file'.ljust(76,".")),
	if p_dic['output_barcodes_file']:
		print 'Yes'
		print('		Output format'.ljust(62,".")),
		print p_dic['barcode_format']
	else:
		print 'No'


	#validate the minimum proportion of Q20 bases necessary to append a contig to the 
	# project contig FASTA file. The value must be between 0.0 and 1.0. A value of 0.0
	#  means append all contigs.	
	print('Checking if minimum QC value to append to FASTA file is valid'.ljust(76,".")),
	p_dic['barcode_min_qc'] = to_float(p_dic['barcode_min_qc'])
	min_qc_value(p_dic['barcode_min_qc'])
	print 'OK'
	
	#check if running NCBI Blast. If so:
	# check if blast program and database are valid options
	print('Checking if running NCBI Blast'.ljust(76,".")),
	#if running NCBI Blast, check if program and database are valid
	if p_dic['run_NCBIBlast']:
		print 'Yes'
		
		print('		Validating NCBI Blast program and database'.ljust(62,".")),
		validate_ncbi_blast(p_dic['blast_flavour'],p_dic['blast_db'])
		print 'OK'
	else:
		print 'No'
	
	#check if running local Blast. If so:
	# check if blast program is installed locally
	# check if blast search database is also stored locally
	print('Checking if running local Blast'.ljust(76,".")),
	#if running local blast, check if the program and database are valid
	if p_dic['run_localBlast']:
		print 'Yes'
		
		print('		Checking if local instance of Blast exists'.ljust(62,".")),
		is_exe(p_dic['localBlast_path'])
		print 'OK'
		
		print('		Checking if can find local Blast DB'.ljust(62,".")),
		p_dic['path_local_db'] = validate_file(p_dic['path_local_db'])	
		print 'OK'
	else:
		print 'No'
	
	#Check if user wants to output read HTML reports for import into a Wiki	
	print('Checking if outputting reads QC HTML report'.ljust(76,".")),
	if p_dic['out_read_HTML']:
		print 'Yes'
	else:
		print 'No'
	
	#Check if user wants to output contig HTML reports for import into a Wiki		
	print('Checking if outputting contigs QC HTML report'.ljust(76,".")),
	if p_dic['out_contig_HTML']:
		print 'Yes'
	else:
		print 'No'
	
	#print some closing information
	print ' '
	print 'All parameters successfully parsed...'
	print ' '
	print '#'*80
	
	close_file(f)
	return p_dic