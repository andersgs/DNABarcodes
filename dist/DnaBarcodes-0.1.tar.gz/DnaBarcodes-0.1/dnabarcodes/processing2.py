from stage2 import div
import os
import subprocess
import re
import shutil
'''
Functions to process chromats into barcodes
'''
def phred_phrap(barcode_obj,vectorfile):
	div()
	print "Processing sample: {}.".format(barcode_obj.id)
	os.chdir(os.path.join(barcode_obj.assembly_path,"edit_dir"))
	shutil.copy2(vectorfile, '../vector.seq')
	subprocess.call(['phredPhrap'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
	print "Done..."
	div()

#because editing with Consed can result in more than one ace file in the directory, we should always pick the latest file. Versions of ace files have increasing integer suffixes after the .ace suffix. For instance, *.ace.1 is an earlier version of *.ace.2
def pick_latestAce(folder):
	ace_files = [f for f in os.listdir(folder) if re.search("ace",f)]
	ace_files.sort(reverse=True)
	return os.path.join(folder,ace_files[0])