#!/bin/sh

#auxiliary functions

test_version(){
	if [ $(echo "$1 >= $2" | bc) ]
		then
			echo "$3 installed, and version compliant (min: $1; installed: $2)."
		else
			echo "$3 installed, but version is less than required (min: $1; installed: $2)."
			case $3 in
				python*)
					while true; do
						read -p "Do you wish to update $3 now? [y]es or [n]" yn
						case $yn in
							[Yy]*)
								install_python_mac
								break
								;;
							[Nn]*) 
								echo "Please install $3 before continuing"
								exit 1
								;;
							*) 
								echo "Please answer Yes or No."
								;;
							esac
					done
					;;
				perl*)
					while true; do
						read -p "Do you wish to update $3 now? [y]es or [n] " yn
						case $yn in
							[Yy]*)
								install_perl_mac
								break
								;;
							[Nn]*) 
								echo "Please install $3 before continuing"
								exit 1
								;;
							*) 
								echo "Please answer Yes or No."
								;;
							esac
					done
					;;
				esac
		fi
}

install_port(){
	curl -O http://svn.macports.org/repository/macports/downloads/MacPorts-1.5.0/MacPorts-1.5.0-10.4.dmg
	hdiutil attach MacPorts-1.5.0-10.4.dmg
	sudo installer -verbose -pkg /Volumes/MacPorts-1.5.0/MacPorts-1.5.0.pkg -target /
	sudo port -v selfupdate
	hdiutil detach -verbose /Volumes/MacPorts-1.5.0/
	hash -r	
}


install_python_mac(){
	sudo port install python27
	if [ $(command -v /usr/bin/python) ]
	then
		sudo mv /usr/bin/python /usr/bin/python-orig
	fi
	sudo port select --set python python27
	hash -r
}

install_perl_mac(){
	sudo port install perl5.12
	if [ $(command -v /usr/bin/perl) ]
	then
		sudo mv /usr/bin/perl /usr/bin/perl-orig
	fi
	sudo port select --set perl perl512
	hash -r
}

install_ncbi_mac(){
	echo "Checking for latest version..."
	latest_version=`curl 'ftp://ftp.ncbi.nlm.nih.gov/blast/executables/blast+/LATEST/' --list-only | grep 'dmg'`
	
	echo "Downloading latest version..."
	curl -O "ftp://ftp.ncbi.nlm.nih.gov/blast/executables/blast+/LATEST/$latest_version"
	
	echo "Unpacking and installing..."
	hdiutil attach $latest_version
	latest=`echo $latest_version | sed 's/\(.\)\.dmg/\1/'`
	pkg=`echo $latest_version | sed 's/\(.\)\.dmg/\+\.pkg/'`
	sudo installer -verbose -pkg /Volumes/$latest/$pkg -target /
	hdiutil detach -verbose /Volumes/$latest/
	hash -r
}

install_phed_mac(){
	echo "Checking for Phred package..."
	
	
	if [ -e packages/phred.zip ]
	then
		cd packages/
		unzip phred.zip
		mkdir phred_src
		mkdir phd2fasta_src
		mv phred-dist-020425.c-acd.tar.Z phred_src
		mv phd2fasta-acd-dist.tar.Z phd2fasta_src
		cd phred_src
		tar xvZf phred-dist-020425.c-acd.tar.Z
		sed -i .bk 's/-O/-O3/' Makefile
		sed -i .bk 's/CC= cc/CC= gcc/' Makefile
		make
		if [ -e phred ] && [ ! debug ]
		then
			install_bin phred
			install_etc phredpar.dat
			echo ' ' >> ~/.bash_profile
			echo '#######Inserted by DNABarcodes install script#######' >> ~/.bash_profile
			echo ' ' >> ~/.bash_profile
			if [ -e /usr/local/etc/phredpar.dat ]
			then
				echo 'PHRED_PARAMETER_FILE=/usr/local/etc/phredpar.dat' >> ~/.bash_profile
			else
				echo 'PHRED_PARAMETER_FILE=$HOME/etc/phredpar.dat' >> ~/.bash_profile
			fi
			echo '' >> ~/.bash_profile
			echo '#######End of insert by DNABarcodes install script######' >> ~/.bash_profile
			echo '' >> ~/.bash_profile
		elif [ -e phred ] && [ debug ]
		then
			echo "Compiling phred was successful"
		else
			echo "Compiling phred failed"
			echo "Please double check that you have XCode installed"
			exit 1
		fi
		
		cd ../phd2fasta_src
		tar xvZf phd2fasta-acd-dist.tar.Z 
		sed -i .bk 's/-O/-O3/' Makefile 
		sed -i .b 's/cc=cc/cc=gcc/' Makefile
		make
		if [ -e phd2fasta ] && [ ! debug ]
		then
			install_bin phd2fasta
		elif [ -e phd2fasta ] && [ debug ]
		then
			echo 'Success in compiling phd2fasta'
		else
			echo "Compiling phd2fasta failed"
			echo "Please double check that you have XCode installed"
			exit 1
		fi
		cd ..
		rm -rdf phred_src phd2fasta_src
		rm phred-dist*.tar.gz
		cd ..
	else
		echo "Could not find Phred package"
	fi
}


install_phrap_mac(){
	echo "Checking for Phrap package..."
	if [ -e  packages/phrap.tar.gz ]
	then
		cd packages/
		mkdir phrap_src
		cp phrap.tar.gz phrap_src
		cd phrap_src
		tar xvzf phrap.tar.gz
		sed -i .b 's/CC= cc/CC= gcc/' makefile
		sed -i .b 's/CFLAGS= -O2/CFLAGS= -O2 -ansi/' makefile
		make
		if [ -e phrap ] && [ ! debug ]
		then
			echo "Nothing yet"
		elif [ -e phrap ] && [ debug ]
		then
			echo "Successfully compiled phrap"
			cd ..
			rm -rdf phrap_src
		else
			echo "No success compiling phrap"
		fi
	fi
}


install_polyphred_mac(){
	echo "Checking for PolyPhred package..."
	if [ -e packages/polyphred.tar.gz ]
	then
	
	else
		echo "Could not find the polyphred package"
		echo "Please make sure to download it before continuing"
		exit 1	
	fi


}

install_consed_mac(){
	echo "Checking for Consed package..."
	if [ -e  packages/consed.tar.gz ]
	then
		cd packages/
		mkdir consed_src
		cp consed.tar.gz consed_src
		cd consed_src
	
		exe1=consed_mac_intel
		exe2=consed_map_ppc

		err=$(./$exe1 -v 2>&1 | sed -n '/bash/p')

		if [ ${#err} -gt 0 ]
		then
			err=$(./$exe2 -v 2>&1 | sed -n '/bash/p')
			if [ ${#err} -gt 0 ]
			then
				echo "None of the available consed versions work with your system."
				echo "Please try to download a compatible version"
				exit 1
			else
				exe=$exe2
			fi
		else
			exe=$exe1
		fi
	then
		echo "Could not find the consed package"
		echo "Please make sure to download it before continuing"
		exit 1
	fi

}

install_bin(){
	install_loc=$1
	echo 'Do you wish to install system wide or locally?[y/n]'
	read ans
	if [ ans == 'y' ]
	then
		if [ $EUID != 0 ]
		then
		  sudo "$0" "$@"
		  if [ -d $install_loc ]
		  then
			  cp $1 /usr/local/genome/bin
		  else
		  	  mkdir -p $install_loc
		  	  cp $1 /usr/local/genome/bin
		  fi
		fi
	else
		if [ -d ~/bin ]
		then
			cp $1 ~/bin
		else
			mkdir ~/bin
			cp $1 ~/bin
		fi
	fi

}

install_etc(){
	etc_dir=$1
	echo 'Do you wish to install system wide or locally?[y/n]'
	read ans
	if [ ans == 'y' ]
	then
		if [ $EUID != 0 ]
		then
		  sudo "$0" "$@"
		  if [ -d $etc_dir ]
		  then
			  cp $1 /usr/local/genome/lib
		  else
		  	  mkdir -p $etc_dir
		  	  cp $1 /usr/local/genome/lib
		  fi		  
		fi
	else
		if [ -d ~/etc ]
		then
			cp $1 ~/etc
		else
			mkdir ~/etc
			cp $1 ~/etc
		fi
	fi
}

test_gcc_mac(){
	clang=`eval gcc --version 2>&1 | grep 'clang'`
	if [ ! ${#clang} ]
	then
		echo "Using Apples default compiler"
		echo "You should upgrade"
		echo "Do you wish to upgrade? [y/n]"
		while true
		do
			read ans
			if [ $ans == 'y' ]
			then
				sudo port install gcc46
				sudo port select --set gcc mp-gcc46
				break
			elif [ $ans == 'n' ]
			then
				echo "Sorry, cant proceed."
				echo "A newer version of GCC is needed to successfully install Phred/Phrap/Consed/PolyPhred"
				exit 1
			else
				echo "Must type y or n"
				echo "Press any key to continue..."
				read key
			fi
		done
	else
		gversion=`eval gcc --version 2>&1| sed -n 's/.*\(4.[6,7,8]\).*$/\1/p'`
		if [ $(echo "$gversion >= $gcc" | bc) ]
		then
			echo "Your current version of gcc is $gversion, which is => then the required version: $gcc"
		else
			echo "Your current version of gcc, $gversion, is not suitable"
			echo "You should upgrade your gcc to version 4.6"
			echo "Do you wish to upgrade? [y/n] "
			while true
			do
				read ans
				if [ $ans == 'y' ]
				then
					sudo port install gcc46
					sudo port select --set gcc mp-gcc46
					break
				elif [ $ans == 'n' ]
				then
					echo "Sorry, cant proceed."
					echo "A newer version of GCC is needed to successfully install Phred/Phrap/Consed/PolyPhred"
					exit 1
				else
					echo "Must type y or n"
					echo "Press any key to continue..."
					read key
				fi
			done
		fi
	fi
			
}

echo ""
echo "Script to install dnaBarcodes"
echo "version 0.1dev"
echo "(C) 2014 Anders Goncalves da Silva and Rohan H Clarke"
echo "====================================================="
echo ""

debug=false

while getopts ":d:" optname
	do
		case $optname in
			d*)
				debug=true
			;;
		esac
	done

pyversion=2.7
plversion=5.12
gcc=4.6

case $OSTYPE in
  darwin*)
  	echo 'Current OS is ' $OSTYPE
     #check if ports is installed
     echo 'Checking macport installation'
     if [ ! $(command -v port) ]
     	then
     		while true; do
     			read -p "Macports not installed, do you wish to install it now? [y]es or [n]" yn
     			case $yn in
     				[Yy]*)
     					sudo install_port
     					break
     					;;
     				[Nn]*) 
     					echo "Please install macports before continuing"
     					exit 1
     					;;
					*) 
						echo "Please answer Yes or No."
						;;
					esac
			done
     	else
     		if [ ! debug ] #uncomment line before release
     			then
	     			sudo port selfupdate
	     	fi
     fi
     
     
     #check for python installation
     echo "Checking python installation"
     if [ ! $(command -v python) ]
     	then
     		while true; do
     			read -p "Python not installed, do you wish to install it now? [y]es or [n]" yn
     			case $yn in
     				[Yy]*)
     					install_python_mac
     					break
     					;;
     				[Nn]*) 
     					echo "Please install python before continuing"
     					exit 1
     					;;
					*) 
						echo "Please answer Yes or No."
						;;
					esac
			done
		else
		 	local_pyversion=`python --version 2>&1 | sed -n 's/.*\([0-9]\.[0-9]\)\.[0-9]/\1/p'`
     fi
     
      #local_pyversion=`python --version 2>&1 | cut -d\  -f2`
      test_version $pyversion $local_pyversion python
      
      #checking for perl installation
      echo ""
      echo "Testing perl installation"
      if [ ! $(command -v perl) ]
      	then
      		while true; do
      			read -p "Perl not installed, do you wish to install it now? [y]es or [n]" yn
     			case $yn in
     				[Yy]*)
     					install_perl_mac
     					break
     					;;
     				[Nn]*) 
     					echo "Please install perl before continuing."
     					exit 1
     					;;
					*) 
						echo "Please answer [Y]es or [N]o."
						;;
					esac
			done
		else
		 	local_plversion=`perl -v 2>&1 | sed -n 's/.*v\(5\.[0-9]\{1,\}\)\.[0-9]\{0,\}.*/\1/p'`
     fi
      
     test_version $plversion $local_plversion perl 

	#testing NCBI
	echo ""
	echo "Testing NCBI blast installation"
	if [ ! $(command -v blastn) ]
		then
      		while true; do
      			read -p "NCBI tools not installed, do you wish to install it now? [y]es or [n]" yn
     			case $yn in
     				[Yy]*)
     					install_ncbi_mac
     					break
     					;;
     				[Nn]*) 
     					echo "Please install NCBI tools before continuing."
     					exit 1
     					;;
					*) 
						echo "Please answer Yes or No."
						;;
					esac
			done
		else
			echo "NCBI blast tools installed."
	fi

	#testing gcc
	echo ""
	echo "Testing gcc installation"
	if [ $(command -v gcc) ]
		then
			test_gcc_mac
		else
			echo "No compiler tools installed"
			echo "Please install Xcode Developer Tools before continuing"
			exit 1
	fi
	
	#installing phred
	echo ""
	echo "Installing phred"
	install_phed_mac
	
	#installing phrap
	echo ""
	echo "Installing phrap and phd2fasta"
	install_phrap_mac
      
     ;;
#Linux installation     
  linux*)
     command -v python >/dev/null 2>&1 || { echo >&2 "I require python but it's not installed.  Aborting."; exit 1; }
     ;;
     
#Windows installation     
  Cygwin)
     command -v python >/dev/null 2>&1 || { echo >&2 "I require python but it's not installed.  Aborting."; exit 1; }
     ;;
     *)
esac
